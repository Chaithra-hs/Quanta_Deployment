import secrets
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, renderer_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from .serializers import UserList, InviteList, UserInfo, DCUserSerializer
from ..models import ReconUser, InviteDetails, DCUser
from ..utils.email_util import send_mail
from ..utils.constants import INVITE_CONTENT, REACT_APP_URL, RESET_CONTENT
from ..utils.token_util import save_token, validate_token
from ..utils.user_permissions import is_write_permitted, is_admin
import datetime
from ..utils.pgsql_conn import call_admin_query
import requests
from Crypto.Cipher import AES
import re

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_invite(request):
    email = request.data.get('email')
    access_type = request.data.get('access_type')
    role = request.data.get('role')

    if is_admin(request.user.email):
        if InviteDetails.objects.filter(email=email).exists():
            response_data = {
                'status': 6002,
                'message': 'Invite was already sent to the user!'
            }
        elif ReconUser.objects.filter(email=email).exists():
            response_data = {
                'status': 6002,
                'message': 'User already exists for this mail!'
            }
        else:
            token = secrets.token_hex(32)
            button_url = REACT_APP_URL + 'register?token=' + token + '&email=' + email

            mail_context = {'name': 'there', 'button_label': 'Join now!',
                            'url': button_url, 'content': INVITE_CONTENT}
            send_mail(email, 'You are invited | Data Recon', mail_context)
            save_token(email, token, 'Pending', 1, 'INVITE')
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

            new_invite = InviteDetails(email=email, status='Pending',
                                       role=role, access_type=access_type, token=token, created_date=current_date)
            new_invite.save()
            response_data = {
                'status': 200,
                'message': 'Invite sent successfully!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for invite !'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def user_add(request):
    email = request.data.get('email')
    firstName = request.data.get('firstName')
    lastName = request.data.get('lastName')
    password = request.data.get('password')
    token = request.data.get('token')
    reg_ex ="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$"
    accepted = re.fullmatch(reg_ex,password)            
    if email and firstName and lastName and password and token:
        if not accepted:
            response_data = {
                        'status': 6002,
                        'message': 'Password must contain at least 12 characters, including at least 2 uppercase letters, 2 lowercase letters, 1 digit, and 1 special character.'
                    }
        else:    
            if validate_token(email, token, 'INVITE'):
                if ReconUser.objects.filter(email=email).exists():
                    response_data = {
                        'status': 6002,
                        'message': 'This email id already exists!'
                    }
                elif InviteDetails.objects.filter(email=email).exists():
                    invite_instance = InviteDetails.objects.filter(email=email)[0]
                    role = invite_instance.role
                    access_type = invite_instance.access_type

                    ReconUser.objects.create_user(email=email, username=email, password=password)
                    ReconUser.objects.filter(email=email).update(first_name=firstName, last_name=lastName, role=role,
                                                                access_type=access_type, admin_tag=False)

                    delete_email = InviteDetails.objects.filter(email=email)
                    delete_email.delete()
                    response_data = {
                        'status': 200,
                        'message': 'Registration successful!'
                    }
                else:
                    response_data = {
                        'status': 6002,
                        'message': 'Invalid Email id!'
                    }
            else:
                response_data = {
                    'status': 6002,
                    'message': 'Invalid / Expired link'
                }
    else:
        response_data = {
            'status': 6002,
            'message': 'Please provide all required fields!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def forgot_password(request):
    email = request.data.get('email')

    is_user_active = ReconUser.objects.get(email=email).is_active

    if not is_user_active:
        response_data = {
            'status': 6002,
            'message': 'Your account has been deactivated!, please contact admin'
        }

    elif ReconUser.objects.filter(email=email).exists():
        token = secrets.token_hex(32)
        button_url = REACT_APP_URL + 'reset?token=' + token + '&email=' + email
        mail_context = {'name': 'there', 'button_label': 'Reset Password',
                        'url': button_url, 'content': RESET_CONTENT}
        send_mail(email, "Reset Password | Data Recon", mail_context)

        save_token(email, token, 'Pending', 180, 'FORGOT')
        response_data = {
            'status': 200,
            'message': 'Reset password link is sent to the mail!'
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'No user found with specified email'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def reset_password(request):
    email = request.data.get('email')
    token = request.data.get('token')
    password = request.data.get("password")

    if validate_token(email, token, 'FORGOT'):
        if ReconUser.objects.filter(email=email).exists():
            new_password = ReconUser.objects.get(email=email)
            new_password.set_password(password)
            new_password.save()

            response_data = {
                'status': 200,
                'message': 'Password updated successfully!',
            }
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid Email id'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Invalid / Expired link!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_list(request):
    instance = ReconUser.objects.all()
    serialized = UserList(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def invite_list(request):
    instance = InviteDetails.objects.all()
    serialized = InviteList(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_user(request):
    email = request.data.get('email')
    role = request.data.get('role')
    access_type = request.data.get('access_type')
    is_active = request.data.get('is_active')
    onestream = request.data.get('onestream')

    if is_admin(request.user.email):
        if ReconUser.objects.filter(email=email).exists():
            ReconUser.objects.filter(email=email).update(role=role, access_type=access_type, is_active=is_active,
                                                         onestream=onestream, admin_tag=request.user.email)
            instance = ReconUser.objects.all()
            serialized = UserList(instance, many=True)
            response_data = {
                'status': 200,
                'data': serialized.data,
                'message': 'User Updated successfully!'
            }
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid email id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Only admin have access for Update user!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_info(request):
    email = request.data.get('email')

    if ReconUser.objects.filter(email=email).exists():
        instance = ReconUser.objects.filter(email=email)[0]
        serialized = UserInfo(instance)

        response_data = {
            'status': 200,
            'data': serialized.data
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'No User found with the specified id!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_delete(request):
    email = request.data.get('email')

    if is_admin(request.user.email):
        if ReconUser.objects.filter(email=email).exists():
            response = call_admin_query("DELETE FROM \"admin\".auth_user WHERE email='" + email + "'")
            if response['status'] == 200:
                response_data = {
                    'status': 200,
                    'message': 'User Deleted successfully!'
                }
            else:
                response_data = response
        else:
            response_data = {
                'status': 6002,
                'message': 'No User found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for Delete!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def resend_invite(request):
    email = request.data.get('email')

    if is_admin(request.user.email):
        if InviteDetails.objects.filter(email=email).exists():
            instance = InviteDetails.objects.filter(email=email)[0]
            access_type = instance.access_type
            role = instance.role

            token = secrets.token_hex(32)
            button_url = REACT_APP_URL + 'register?token=' + token + '&email=' + email

            mail_context = {'name': 'there', 'button_label': 'Join now!',
                            'url': button_url, 'content': INVITE_CONTENT}
            send_mail(email, 'You are invited | Data Recon', mail_context)
            save_token(email, token, 'Pending', 1, 'INVITE')
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

            new_invite = InviteDetails.objects.filter(email=email).update(role=role, access_type=access_type,
                                                                          status='Pending', token=token,
                                                                          created_date=current_date)
            response_data = {
                'status': 200,
                'message': 'Invite sent successfully!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for invite !'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_config(request):
    tenant_id = request.data.get('tenant_id')
    client_id = request.data.get('client_id')
    client_secret = request.data.get('client_secret')
    onestream_url = request.data.get('url')
    osname = request.data.get('osname')
    email = request.user.email

    if is_admin(request.user.email):

        payload = 'grant_type=client_credentials&Scope=api://' + client_id + '/.default'
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        url = "https://login.microsoftonline.com/" + tenant_id + "/oauth2/v2.0/token"

        response = requests.post(url, headers=headers, data=payload, auth=(client_id, client_secret))
        if response.status_code == 200:

            client_secret = client_secret.encode()
            key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"
            cipher = AES.new(key, AES.MODE_EAX)
            nonce = cipher.nonce
            client_secret, tag = cipher.encrypt_and_digest(client_secret)

            if DCUser.objects.filter(email=email, osname=osname).exists():
                DCUser.objects.filter(email=email).update(dc_username=client_id, dc_password=client_secret,
                                                          dc_url=onestream_url, tenant_id=tenant_id, tag=tag,
                                                          nonce=nonce, osname=osname)
            else:
                dc_user = DCUser(import_type=3, dc_username=client_id, dc_password=client_secret,
                                 dc_url=onestream_url, tenant_id=tenant_id, email=email, tag=tag, nonce=nonce,
                                 osname=osname)
                dc_user.save()
                # dc_user = DCUser(app_name="1", import_type=3, dc_username=client_id, dc_password=client_secret,
                #                  dc_url=onestream_url, tenant_id=tenant_id, email=email, tag=tag, nonce=nonce)
                # dc_user.save()
            response = response.json()
            ReconUser.objects.filter(email=email).update(admin_tag=email)
    else:
        response = {
            'status': 6002,
            'message': 'Only admin has access to configure onestream'
        }
    return Response(response, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_list(request):
    email = request.user.email
    instance = DCUser.objects.filter(email=email)
    serialized = DCUserSerializer(instance, many=True)

    data = serialized.data

    for val in data:
        client_id = val['dc_username']
        cl_len = len(client_id)
        client_id = client_id[-6:]
        cl_str = '*' * cl_len
        client_id = cl_str + client_id
        tenant_id = val['tenant_id']
        tn_len = len(tenant_id)
        tenant_id = tenant_id[-6:]
        tn_str = '*' * tn_len
        tenant_id = tn_str + tenant_id
        val['dc_username'] = client_id
        val['tenant_id'] = tenant_id
        del val['dc_password']
        # print(client_id)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_delete(request):
    email = request.user.email
    osname = request.data.get('osname')
    if is_admin(email):
        instance = DCUser.objects.filter(email=email, osname=osname)
        if email == instance[0].email:
            instance.delete()
        response_data = {
            'status': 200,
            'message': "Delete " + osname + " successfully"
        }

        return Response(response_data, status=status.HTTP_200_OK)
import csv
from ...models import ReconDimensions

'''
<!---------- Method to get the imported bridge file data
             and return as structured data ----------!>
'''


def get_import_data(recon_id, file_path):
    # Creating the data object
    data_object = {
        'status': 200,
        'recon_id': recon_id,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Dim_File:
        next(Dim_File)
        reader = csv.reader(Dim_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                row_object = {
                    "order": row[0],
                    "app1_dimension": row[1].upper(),
                    "app1_dim_in_file": row[2],
                    "app1_type_field": row[3],
                    "app1_top_member": row[4],
                    "app1_is_active": row[5],
                    "app1_app_type": "0",
                    "app2_dimension": row[6].upper(),
                    "app2_dim_in_file": row[7],
                    "app2_type_field": row[8],
                    "app2_top_member": row[9],
                    "app2_is_active": row[10],
                    "app2_app_type": "1",
                }
                data_object['rows'].append(row_object)

    return data_object


def get_dim_id(recon_id, dim_name, app_type):
    dimension_id = 'None'
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type=app_type).exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type=app_type)[0]
        dimension_id = dim_instance.dimensions_id

    return dimension_id

from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('app/list', views.app_list, name='recon_app_list'),
    path('list', views.recon_list, name='recon_list'),
    path('create', views.recon_create, name='recon_create'),
    path('update', views.recon_update, name='recon_update'),
    path('info/<int:recon_id>', views.get_recon_info, name='get_recon_info'),
    path('delete/<int:recon_id>', views.delete_recon, name='delete_recon'),
    path('dim/order/update', views.recon_dim_order_update, name='recon_dim_order_update'),
    path('dim/export/<int:recon_id>', views.dim_export, name='dim_export'),
    path('dim/import', views.get_dim_import, name='get_dim_import'),
    path('dc/info', views.dc_info, name='dc_info'),
    path('delete', views.delete_row, name='delete_row')
]

urlpatterns = format_suffix_patterns(urlpatterns)

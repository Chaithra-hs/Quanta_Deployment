import datetime
from ..models import TokenDetails


def save_token(email, token, status, expiry, token_type):
    now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
    current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

    if token_type == 'FORGOT':
        expiry_date = current_date + datetime.timedelta(minutes=expiry)
    else:
        expiry_date = current_date + datetime.timedelta(days=expiry)

    new_token = TokenDetails(email=email, token=token, status=status,
                             expiry_date=expiry_date, type=token_type,created_date=current_date)
    new_token.save()


def validate_token(email, token, token_type):
    if TokenDetails.objects.filter(email=email, token=token, type=token_type).exists():
        token_instance = TokenDetails.objects.filter(email=email, token=token, type=token_type)[0]
        expiry_date = token_instance.expiry_date
        now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
        current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

        if expiry_date > current_date:
            token_instance.delete()
            return True

    return False

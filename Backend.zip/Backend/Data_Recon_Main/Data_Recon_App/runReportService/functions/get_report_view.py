from django.db import connections
import json


'''
<!---------- Method to do get view data and exclude
            some columns and return data as a response ----------!>
'''


def get_report_view(query):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]
        if headers.__contains__('grand_abs_total'):
            headers = list(map(lambda x: x.replace('grand_abs_total', 'Grand Absolute Total'), headers))
        
        if headers.__contains__('bridge-comment'):
            headers = list(map(lambda x: x.replace('bridge-comment', 'Comments'), headers))
            comments_index = headers.index('Comments')
        
        if headers.__contains__('je-comment'):
            headers = list(map(lambda x: x.replace('je-comment', 'Journal Comments'), headers))
            je_comments_index = headers.index('Journal Comments')
        
        amount_index = headers.index('Grand Absolute Total')
        # comments_index = headers.index('Comments')
        # Getting results
        results = cursor.fetchall()
        # test = tuple(results)
        # print(test[1][3])

        # Converting to JSON
        json_data = []
        for result in results:
            result_list = list(result)
            # Re-formatting data
            result_list[amount_index] = "{:.2f}".format(float(result_list[amount_index]))
            
            if headers.__contains__('Comments'):
                result_list[comments_index] = (result_list[comments_index]).split('^')
            
            if headers.__contains__('Journal Comments'):
                result_list[je_comments_index] = (result_list[je_comments_index]).split('^')

            # Converting back to tuple
            result = tuple(result_list)
            json_data.append(dict(zip(headers, result)))

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)

        # # Getting the variance percentage
        # number_of_rows = len(results)
        # variance_count = get_variance_count(json_rows)
        # variance_percentage = (variance_count / number_of_rows) * 100 if number_of_rows > 0 else 0
        # variance_percentage = "{:.1f}".format(float(variance_percentage)) + '%'

        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Data retrieved successfully!'
            # 'variance_percentage': variance_percentage,
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


# def get_variance_count(result):
#     count = 0
#     for row in result:
#         if row['Grand Absolute Total'] != "0.00":
#             count += 1

#     return count

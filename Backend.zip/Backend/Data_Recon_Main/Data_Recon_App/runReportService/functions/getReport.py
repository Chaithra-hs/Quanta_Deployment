import os
from django.conf import settings

def getReport(recon_id):
    # print(recon_id)
    # zpath = os.path.join('C:\\Recon_Files\\media\\'+str(recon_id)+'\\exports\\','Report.zip')
    zpath = os.path.join(settings.MEDIA_ROOT,str(recon_id) + "/export" + "/Report.zip")
    zpath=zpath.replace('\\','/')
    zip_file = open(zpath,'rb')
    return zip_file.read()
from django.db import connections

'''
<!---------- Method to run report and get view data then
             structure and return response ----------!>
'''
def generateQuery(recon_id, colArr, variance):
    # Convert column Array to string
    colList = ''
    abs_total = ''
    colList_text = ''
    cursor = connections['Recon'].cursor()
    if colArr != '*':
        for x in colArr:
            colList += ',\"'+x+'\"' if colList != '' else '\"'+x+'\"'
    else:
        colList = '*'
    
    grpList = colList
    grpStmt = ''
    # grand_abs_total_flag = False

    if colList != '*':            
        # Converting colList to list to replace Grand absolute total and comment columns to match with database
        colList = list(colList.split(","))
        colSet = colList
        if colList.__contains__('"Grand Absolute Total"'):
            colList.remove('"Grand Absolute Total"')
            # grand_abs_total_flag = True
            # colList = list(map(lambda x: x.replace('"Grand Absolute Total"', 'sum("grand_abs_total") as "grand_abs_total"'), colList))
        
        if colList.__contains__('"Comments"'):
            colList = list(map(lambda x: x.replace('"Comments"', 'string_agg("bridge-comment",\'^\') as "bridge-comment"'), colList))
            colList_text = '"bridge-comment"'


        if colList.__contains__('"Journal Comments"'):
            colList = list(map(lambda x: x.replace('"Journal Comments"', 'string_agg("je-comment",\'^\') as "je-comment"'), colList))
            if colList_text:
                colList_text = colList_text+',"je-comment"'
            else:
                colList_text = '"je-comment"'
    
        # Prepare the group by statement
        query = 'select fileservice.f_get_column_list('+str(recon_id)+',true);'
        cursor.execute(query)
        grpList = ','.join(map(str,cursor.fetchone()))
        
        # Convert list to set
        grpSet = set(grpList.split(","))
        colSet = set(colSet)
        # Intersection to get common columns
        res = colSet.intersection(grpSet)
        # print(res)
        tmpList = ','.join(res)
        grpStmt = ' group by '+','.join(res)

        # print('============================================================================================')
        # Get list of Year-Period combinations and cast ( to - and remove - and sum of the year-periods
        # Do this only if the Year-Period combinations are present in the incoming column list
        query = 'select fileservice.f_get_column_list('+str(recon_id)+',false);'
        cursor.execute(query)
        res = (','.join(map(str,cursor.fetchone()))).split(",")
        for x in res:
            if colList.__contains__(x): 
                colList.remove(x)
                colList = colList + ['sum(case when not abs('+x+') > '+str(variance)+' then 0.00 else '+x+' end) as '+x]

                if abs_total:
                    abs_total = abs_total + ' + abs('+x+')'
                else:
                    abs_total = 'abs('+x+')'
                
                if colList_text:
                    colList_text = colList_text + ', case when '+x+'<0 then \'(\'||abs('+x+')::text||\')\' else '+x+'::text end'
                else:
                    colList_text = 'case when '+x+'<0 then \'(\'||abs('+x+')::text||\')\' else '+x+'::text end'
                
        colList_text = tmpList + ', ' + colList_text
    else:            
        # Generate the where clause
        # Prepare the group by statement
        query = 'select fileservice.f_get_column_list('+str(recon_id)+',false);'
        cursor.execute(query)
        res = (','.join(map(str,cursor.fetchone()))).split(",")
        colList=''
        for x in res:
            if colList:
                colList = colList + ', case when not abs('+x+') > '+str(variance)+'::numeric then 0.00 else '+x+' end as '+x
            else:
                colList = 'case when not abs('+x+') > '+str(variance)+'::numeric then 0.00 else '+x+' end as '+x

            if abs_total:
                abs_total = abs_total + ' + abs('+x+')'
            else:
                abs_total = 'abs('+x+')'
        
            if colList_text:
                    colList_text = colList_text + ', case when '+x+'<0 then \'(\'||abs('+x+')::text||\')\' else '+x+'::text end'
            else:
                colList_text = 'case when '+x+'<0 then \'(\'||abs('+x+')::text||\')\' else '+x+'::text end'

        # Add in the remaining columns
        query = 'select fileservice.f_get_column_list('+str(recon_id)+',true);'
        cursor.execute(query)
        pre_list = ','.join(map(str,cursor.fetchone()))
        colList = pre_list + ', "je-comment", "bridge-comment", ' + colList
        colList_text = pre_list + ', "je-comment", "bridge-comment", ' + colList_text

    if str(type(colList))!='<class \'str\'>':
        # Convert colList from list to starting datatype for the query
        # print('In type')
        colList = ','.join(map(str,colList))
    
    return colList,grpStmt,abs_total,colList_text
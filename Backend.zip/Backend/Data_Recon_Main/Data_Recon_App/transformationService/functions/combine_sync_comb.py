from .sync_combinations import sync_combinations


'''
<!---------- Method to get transformations sync combinations of both
             apps then structure and return response ----------!>
'''


def combine_sync_comb(recon_id):
    app1_sync_comb = sync_combinations(recon_id, '0')
    app2_sync_comb = sync_combinations(recon_id, '1')

    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'app1_dimensions': app1_sync_comb['dimensions'],
        'app2_dimensions': app2_sync_comb['dimensions'],
        'app1_data': convert_data(app1_sync_comb['data']),
        'app2_data': convert_data(app2_sync_comb['data']),
        'message': 'Obtained all the transformation combinations!'
    }

    return response_data


def convert_data(data_list):
    data_obj = []
    for data in data_list:
        data['source_sync'] = data['combinations']
        data.pop('combinations')
        data_obj.append(data)

    return data_obj
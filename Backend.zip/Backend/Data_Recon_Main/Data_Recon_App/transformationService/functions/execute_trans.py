import json
from...bridgeService.functions.is_bridge_exists import is_bridge_exists
from ...utils.pgsql_conn import call_sp_params
from ...utils.get_recon import get_recon
from .get_sync_view import get_sync_view
from ...runImportService.functions.is_exists import is_exists


'''
<!---------- Method to run transformations and get view data
             then structure and return response as file ----------!>
'''

def execute_trans(recon_id, max_rows, page_number,sp_flag):
    recon_data = get_recon(recon_id)
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']
    sp_flag = sp_flag
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows
    # Checking if all bridge configured
    is_valid = is_bridge_exists(recon_id)

    if is_valid['status'] == 200:
        # Calling the transformation run SP
        if sp_flag == True:
            trans_run = call_sp_params('fileservice.sp_create_transformation_sync', [recon_id], 1)

            if trans_run['status'] == 200:
                # Getting both apps data
                view_query = 'SELECT * FROM fileService.bridgesync_' + str(recon_id) + \
                             ' LIMIT ' + str(end_point) + \
                             ' OFFSET ' + str(start_point)
                response_data = get_sync_view(view_query, app1_id, app2_id)
            else:
                response_data = {
                    'status': 6001,
                    'message': 'Something went wrong in Procedure'
                }
        else:
            # Check if view exists
            view_exists = is_exists('fileservice', 'bridgesync_' + str(recon_id))
            if view_exists['rows'][0]['exists']:
                # Getting both apps data
                view_query = 'SELECT * FROM fileservice.bridgesync_' + str(recon_id) + \
                             ' LIMIT ' + str(end_point) + \
                             ' OFFSET ' + str(start_point)
                response_data = get_sync_view(view_query, app1_id, app2_id)
            else:
                response_data = {
                    'status': 6001,
                    'message': 'No data found!'
                }

        return response_data
    else:
        return is_valid

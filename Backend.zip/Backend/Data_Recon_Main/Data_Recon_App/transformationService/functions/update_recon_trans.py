from ... models import ReconTransformation, ReconDimensions
from ..serializers import TransformationSerializer
from ...utils.get_recon import get_recon
from .get_transformations import get_transformations
from .generate_sync import generate_sync


'''
<!---------- Method to create or update recon transformations
             then structure and return response ----------!>
'''


def update_recon_trans(recon_id, trans_rows):

    # Getting recon data
    recon_data = get_recon(recon_id)
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    # Splitting app1 and app2 data
    for row in trans_rows:
        # print('row type: ',type(row['app1_concatenation']))
        if not row['app1_concatenation']:
            app1_concat_dim_id = None
            app1_concat_dim_name = None
        else:
            row['app1_concatenation'] = list(map(str, row['app1_concatenation']))
            app1_concat_dim_id = "-".join(row['app1_concatenation'])
            # print('row concat: ',row['app1_concatenation'],'======',type(row['app1_concatenation']))
            app1_concat_dim_name = get_dim_name_comb(recon_id, row['app1_concatenation'])

        app1_apply_all_members = get_apply_all_members(row['app1_apply_all_members'])

        app1_row = {
            'recon_id': recon_id,
            'app_id': app1_id,
            'dim_id': row['app1_dimension_id'],
            'tgt_concat_dimid': app1_concat_dim_id,
            'tgt_concat_dimname': app1_concat_dim_name,
            'apply_all_members': app1_apply_all_members
        }

        if not row['app2_concatenation']:
            app2_concat_dim_id = None
            app2_concat_dim_name = None
        else:
            row['app2_concatenation'] = map(str, row['app2_concatenation'])
            app2_concat_dim_id = "-".join(row['app2_concatenation'])
            app2_concat_dim_name = get_dim_name_comb(recon_id, row['app2_concatenation'])

        app2_apply_all_members = get_apply_all_members(row['app2_apply_all_members'])
        app2_row = {
            'recon_id': recon_id,
            'app_id': app2_id,
            'dim_id': row['app2_dimension_id'],
            'tgt_concat_dimid': app2_concat_dim_id,
            'tgt_concat_dimname': app2_concat_dim_name,
            'apply_all_members': app2_apply_all_members
        }
        # print('app1_row: ',app1_row)
        # Checking if already exist or need to create
        app1_save = create_or_update(recon_id, app1_row)
        app2_save = create_or_update(recon_id, app2_row)

        # Checking if success
        if app1_save['status'] == 6002:
            return app1_save

        if app2_save['status'] == 6002:
            return app2_save

    response_data = get_transformations(recon_id)
    return response_data


def create_or_update(recon_id, row):
    if ReconTransformation.objects.\
            filter(recon_id=recon_id, app_id=row['app_id'], dim_id=row['dim_id']).exists():
        instance = ReconTransformation.objects.\
            filter(recon_id=recon_id, app_id=row['app_id'], dim_id=row['dim_id'])[0]
        
        serialized = TransformationSerializer(instance, data=row, partial=True)
    else:
        serialized = TransformationSerializer(data=row)
    # print(serialized)
    if serialized.is_valid():
        save_obj = serialized.save()
        response_data = {
            'status': 200,
            'message': 'Created/Update successfully!'
        }

        # Checking if apply all members are true
        if save_obj.apply_all_members:
            generate_sync(recon_id, save_obj.id, row)
    else:
        response_data = {
            'status': 6002,
            'message': serialized.errors
        }

    return response_data


def get_dim_name_comb(recon_id, dim_ids):
    # print('get dim name: ',recon_id,'======',dim_ids)
    # print('get dim type: ',type(recon_id),'======',type(dim_ids))
    dim_name_list = []
    for dim_id in dim_ids:
        # print('In for loop')
        # print('id: ',dim_id)
        instance = ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False, dimensions_id=dim_id)[0]
        dim_name_list.append(instance.dimension)
    dim_name_joined = '-'.join(dim_name_list)
    # print('dim_name_joined: ',dim_name_joined)
    return dim_name_joined


def get_apply_all_members(type_id):
    apply_all_members = None
    if type_id == 1 or type_id == '1':
        apply_all_members = True
    elif type_id == 2 or type_id == '2':
        apply_all_members = False

    return apply_all_members

from django.conf import settings
import pandas as pd
import csv
import time


def pbcs_fccs_etl(recon_id, file_name):

    input_file = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file_name)

    with open(input_file, 'r', encoding='utf-8-sig') as infile:
        reader = csv.DictReader(infile)
        fieldnames = reader.fieldnames
        fc = fieldnames[0]  # first column
    # removing pov and dataload cube columns
    stopwords = ['Point-of-View', fc, 'Data Load Cube Name']
    for fieldname in list(fieldnames):
        if fieldname in stopwords:
            fieldnames.remove(fieldname)
    lofn = len(fieldnames)
    new_list = [x for x in fieldnames if x != '']
    # creating account df
    accdf = pd.read_csv(input_file, usecols=new_list, low_memory=False)
    # creating df with fc and unsplitted pov and geting length of input file
    df = pd.read_csv(input_file, usecols=[fc, 'Point-of-View'], low_memory=False)
    loif = len(df)
    # spliting pov
    df1 = df['Point-of-View'].str.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", regex=True, expand=True)
    lenofreqheader = (df1.shape[1])
    df2 = df.join(df1)
    df2 = df2.drop(['Point-of-View'], axis=1)
    df2new = df
    dflast = pd.DataFrame()
    for i in range(0, lofn):
        dflast = pd.concat([dflast, df2], ignore_index=True)
        # dflast = dflast.append(df2, ignore_index=True) replacing this line since append function is going to be obsolete
    df_melted = accdf.melt(var_name='Account', value_name='Amount')
    dflast = dflast.join(df_melted)
    try:
        dflast = dflast[dflast["Amount"].str.contains("#missing") == False]
    except:
        time.sleep(0)

    # dflast=dflast[dflast["Amount"].str.replace("$", "",regex=True)]

    newheaders = []

    for i in range(len(dflast.columns)):
        newheaders.append('test'+str(i))

    dflast.columns = newheaders

    dflast.to_csv(input_file, index=False)
    dfhead = dflast.head()

    dfhead = dfhead.to_dict(orient='records')

    # print(dfhead)
    return dfhead

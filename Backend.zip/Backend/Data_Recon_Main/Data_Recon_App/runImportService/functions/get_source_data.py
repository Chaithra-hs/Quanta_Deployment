import os
from django.conf import settings

def getSourceData(recon_id):
    zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) +'_'+ "Source_Data_Export.zip")
    if os.name == 'nt':
        zpath=zpath.replace('/','\\')
    # print("zpath is "+str(zpath))
    zip_file = open(zpath,'rb')
    return zip_file.read()

def add_files_to_zip(zip_file, folder_name, files):
    for file in files:
        # Construct the relative path inside the zip
        zip_path = os.path.join(folder_name, os.path.basename(file))
        # Add the file to the zip
        zip_file.write(file, arcname=zip_path)
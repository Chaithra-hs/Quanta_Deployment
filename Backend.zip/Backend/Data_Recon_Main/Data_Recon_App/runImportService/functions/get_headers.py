from ... models import ReconDimensions
from .. serializers import DimensionCombinations

'''
<!---------- Method to get combinations of dimension
             data as a response ----------!>
'''


def get_headers(recon_id):
    dimensions_instance = ReconDimensions.objects.filter(recon_id=recon_id)
    dim_combinations = DimensionCombinations(dimensions_instance, many=True)
    combinations = dict()
    for i in dim_combinations.data:
        for j in i:
            if j in combinations and j != 'app_type':
                if i['app_type'] == '0':
                    combinations[j] = i[j] + '-' + combinations[j]
                else:
                    combinations[j] += '-' + i[j]
            elif j == 'app_type':
                pass
            else:
                combinations[j] = i[j]
    sorted_combinations = dict(sorted(combinations.items(), key=lambda x: int(x[0])))
    merged_combinations = dict({'init': 'App1-App2'})
    merged_combinations.update(sorted_combinations)
    combinations = list(merged_combinations.values())
    return combinations

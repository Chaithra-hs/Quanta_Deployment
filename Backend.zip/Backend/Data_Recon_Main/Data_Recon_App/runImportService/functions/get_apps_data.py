import os
from django.conf import settings
from . get_data import get_data
from . get_cache_data import get_cache_data
from . get_headers import get_headers
from ... utils.get_recon import get_recon


'''
<!---------- Method to get both application data of a recon
             return data as a response ----------!>
'''


def get_apps_data(recon_id, max_rows, page_number):

    # Getting recon and application details
    recon_instance = get_recon(recon_id)
    app1_source_file = recon_instance['app1_source_file']
    app2_source_file = recon_instance['app2_source_file']

    # Getting the combinations
    combinations = get_headers(recon_id)

    if app1_source_file:
        # Generating app1 filepath
        app1_file_path = settings.MEDIA_ROOT + '\\' + str(recon_id) + '\\' + app1_source_file
        app1_source_name = app1_source_file.split('.')
        app1_source_cache_path = settings.MEDIA_ROOT + '\\' + str(recon_id) + '\\' + app1_source_name[0] + '.pkl'

        # Checking if the app1 cache exists
        if os.path.exists(app1_source_cache_path):
            app1_response_data = get_cache_data(recon_id, app1_source_cache_path, max_rows, page_number)
            if app1_response_data['status'] == 200:
                app1_rows = app1_response_data['rows']
                app1_pages = app1_response_data['total_pages']
            else:
                return app1_response_data
        elif os.path.exists(app1_file_path):
            app1_response_data = get_data(app1_file_path, recon_id, '0',
                                          app1_source_file, max_rows, page_number)
            if app1_response_data['status'] == 200:
                app1_rows = app1_response_data['rows']
                app1_pages = app1_response_data['total_pages']
            else:
                return app1_response_data
        else:
            response_data = {
                'status': 6002,
                'message': 'App1 source file not found in server.'
            }
            return response_data
    else:
        app1_rows = []

    if app2_source_file:
        # Generating app2 filepath
        app2_file_path = settings.MEDIA_ROOT + '\\' + str(recon_id) + '\\' + app2_source_file
        app2_source_name = app2_source_file.split('.')
        app2_source_cache_path = settings.MEDIA_ROOT + '\\' + str(recon_id) + '\\' + app2_source_name[0] + '.pkl'

        # Checking if the app2 cache exists
        if os.path.exists(app2_source_cache_path):
            app2_response_data = get_cache_data(recon_id, app2_source_cache_path, max_rows, page_number)
            if app2_response_data['status'] == 200:
                app2_rows = app2_response_data['rows']
                app2_pages = app2_response_data['total_pages']
            else:
                return app2_response_data
        elif os.path.exists(app2_file_path):
            app2_response_data = get_data(app2_file_path, recon_id, '1',
                                          app2_source_file, max_rows, page_number)
            if app2_response_data['status'] == 200:
                app2_rows = app2_response_data['rows']
                app2_pages = app2_response_data['total_pages']
            else:
                return app2_response_data
        else:
            response_data = {
                'status': 6002,
                'message': 'App2 source file not found in server.'
            }
            return response_data
    else:
        app2_rows = []

    # Merging both app data
    response_data = {
        'status': 200,
        'current_page': page_number,
        'total_pages': int(app1_pages) + int(app2_pages),
        'headers': combinations,
        'app1_rows': app1_rows,
        'app2_rows': app2_rows,
        'message': 'Source file data retrieved successfully!'
    }

    return response_data

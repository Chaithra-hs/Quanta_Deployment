from rest_framework import serializers
from .. models import ReconUser


class UserListSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconUser
        fields = ('uuid', 'first_name', 'last_name', 'email', 'is_active', 'last_login', 'access_type', 'role', 'onestream')

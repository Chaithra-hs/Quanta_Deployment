import copy
import csv
from datetime import datetime
import os
from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from .. utils.run_export_script import run_export_script
from .. models import ReconDimensions, Recon, ReconBridgeMapping
from .serializers import DimensionNameSerializer, BridgeGetSerializer
from rest_framework.parsers import MultiPartParser, FormParser
from .. utils.store_file import store_file
from django.db import connections
from .functions.get_import_data import get_dim_id, get_formated_bridge_data, get_import_data
from .functions.convert_bridge import convert_bridge
from .functions.save_bridge import save_bridge
from .functions.get_bridge_data import get_bridge_data
from .functions.get_export_data import get_export_data, get_comment_export_data, \
    get_kick_out_export_data, get_run_bridge_export_data
from .functions.add_bridge_id import add_bridge_id, add_comment_bridge_id
from .functions.get_import_comments import get_import_comments
from .functions.update_comments import update_comments
from .functions.get_comments import get_comments
from .. utils.get_recon import get_recon
from .. utils.pgsql_conn import call_sp_params
from .functions.get_view_data import get_view_data, get_kick_out_view_data
from .functions.get_import_kick_outs import get_import_kick_outs
from .functions.update_outs import update_outs
from .functions.is_bridge_exists import is_bridge_exists
from .functions.is_valid_file import is_valid_file
from ..runImportService.functions.is_exists import is_exists
from django.conf import settings
from ..utils.user_permissions import is_write_permitted
import pandas as pd
from .functions.add_dim_name import add_dim_name
from ..utils.export_query import bridge_query, comment_query, bridge_kick_out_query, run_bridge_export_query

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dimension_names_list(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        app_01_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='0', is_active=True).order_by('dimensions_id','turn_on_define_order')
        app_01_serialized = DimensionNameSerializer(app_01_instance, many=True)
        
        app_02_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='1', is_active=True).order_by('dimensions_id','turn_on_define_order')
        app_02_serialized = DimensionNameSerializer(app_02_instance, many=True)
        response_data = {
            'status': 200,
            'recon_id': recon_id,
            'app_01_dimension': app_01_serialized.data,
            'app_02_dimension': app_02_serialized.data,
        }
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def bridge_list(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        base_data = get_bridge_data(recon_id, '01', 'full')
        response_data = add_dim_name(recon_id, base_data)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def bridge_update(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    bridge_data = request.data

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # adding dim_id for new entry scenario
            formated_data = get_formated_bridge_data(recon_id,app_type,bridge_data)
            save_data = save_bridge(formated_data)
            if save_data['status'] == 6002:
                response_data = save_data
            else:
                base_data = get_bridge_data(recon_id, app_type, 'partial')
                response_data = add_dim_name(recon_id, base_data)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_bridge(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']
    file_obj = request.FILES['bridge_file']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Get the imported file data
                file_data = get_import_data(recon_id, app_type, file_path)
                response_data = copy.deepcopy(file_data)

                # Saving the bridge info
                if file_data['status'] == 200:
                    bridge_data = convert_bridge(file_data)
                    save_data = save_bridge(bridge_data)

                    if save_data['status'] == 6002:
                        response_data = save_data
                    else:
                        response_data = add_bridge_id(response_data)
                        # base_data = get_bridge_data(recon_id, app_type, 'F')
                        response_data = add_dim_name(recon_id, response_data)

            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)

'''
<!---------- Method to import or update bridges from json data
             and return a response ----------!>
'''
# @api_view(['PUT'])
# @permission_classes((IsAuthenticated,))
# @renderer_classes((JSONRenderer,))
# def import_single_bridge(request):
#     # Getting the data from request
#     data_object = request.data
#     recon_id = data_object['recon_id']
#     app_type = data_object['app_type']
    
    

#     if is_write_permitted(request.user.email):
#         if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            
#             # getting updated file data from data_object
#             file_data = get_formated_file_data(recon_id,app_type,data_object)
#             response_data = copy.deepcopy(file_data)

#             # Saving/update the bridge info
#             # print('file'+str(file_data))
#             bridge_data = convert_bridge(file_data)
#             # print('bridge'+str(bridge_data))
#             save_data = save_bridge(bridge_data)

#             if save_data['status'] == 6002:
#                 response_data = save_data
#             else:
#                 response_data = add_bridge_id(response_data)
#                 response_data = add_dim_name(recon_id, response_data)
 
#         else:
#             response_data = {
#                 'status': 403,
#                 'message': 'No recon found with the specified id!'
#             }
#     else:
#         response_data = {
#             'status': 6002,
#             'message': 'Un-authorized action detected!'
#         }
#     return Response(response_data, status=status.HTTP_200_OK)

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_bridge(request):
    recon_id = request.data['recon_id']
    bridge_id = request.data['bridge_id']

    if is_write_permitted(request.user.email):
        for bridge in bridge_id:
          if ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge, app_type='0').exists():
            instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge)
            bridge_member = instance[0].bridge_member
            instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_member=bridge_member)
            instance.delete()


            response_data = {
                'status': 200,
                'message': 'Bridge deleted successfully!'
            }
          else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_bridge(request):
    recon_id = request.data['recon_id']
    app_type = request.data['app_type']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            app_key = 'App1' if app_type == '0' else 'App2'
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = app_key + '_Bridge_Export.csv'
            # export_file = get_export_data(recon_id, app_type)

            # Calling functions for query
            query = bridge_query(recon_id, app_type)

            # Calling the Shell script to create a csv file
            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))

            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response_data = HttpResponse(fh.read(), content_type="text/csv")
                    response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response_data
            else:
                response_data = {
                    'status': 6002,
                    'message': "File Not Found"
                }

        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_comments(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    file_obj = request.FILES['comments_file']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Getting file data
                response_data = get_import_comments(recon_id, file_path, False)
                response_data = add_comment_bridge_id(response_data)
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_update(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    comment_data = request.data['rows']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = update_comments(recon_id, comment_data, False)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_list(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        response_data = get_comments(recon_id, False)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_comment(request):
    recon_id = request.data['recon_id']
    bridge_id = request.data['bridge_id']
    app_type = request.data['app_type']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge_id)[0]
            if not app_type == '2':
                instance.dim_comment = None
            else:
                instance.bridge_comment = None
            instance.save()

            response_data = {
                'status': 200,
                'message': 'Comment deleted successfully!'
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_export(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        current_time = datetime.now().time().strftime("%H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d")
        modified_date = str(current_date) + '_' + str(current_time)
        file_name = 'Bridge_Comments_Export.csv'
        # export_file = get_comment_export_data(recon_id, False)

        # Calling function for export query
        query = comment_query(recon_id)

        # Calling the Shell script to create a csv file
        run_export_script(recon_id, file_name, query)

        file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
        file_path = (str(file_path).replace("\\", "/"))

        if os.path.exists(file_path):
            with open(file_path, 'rb') as fh:
                response_data = HttpResponse(fh.read(), content_type="text/csv")
                response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                return response_data
        else:
            response_data = {
                'status': 6002,
                'message': 'File Not Found'
            }

        # Setting the download response
        # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
        # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
        # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
        # return response_data
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_bridge(request):

    # Getting the data from request
    recon_id = request.data['recon_id']
    je_flag = request.data['je_flag']
    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    if (request.data['sp_flag']):
        sp_flag = request.data['sp_flag']
    else:
        sp_flag = False


    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        recon_name = recon_data['name']
        app1_id = recon_data['app1_id']
        app2_id = recon_data['app2_id']

        # Check if view exists
        if(je_flag):
            view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))
        else:
            view_exists = is_exists('fileservice', 'view_' + str(recon_id))


        if view_exists['rows'][0]['exists']:
            # Checking if all bridge configured
            is_valid = is_bridge_exists(recon_id)

            if is_valid['status'] == 200:
                # Calling the bridge run SP
                if sp_flag:
                  bridge_run = call_sp_params('fileService.sp_create_recon_run_bridge_table', [recon_id,je_flag], 2)
                  if bridge_run['status'] != 200:
                      response_data = bridge_run
                      return response_data

                else:
                    return Response(status=status.HTTP_200_OK)
                if bridge_run['status'] == 200:
                    # Getting both apps data
                    if(je_flag):
                        view_query = 'SELECT * FROM fileService.view_bridge_je_' + str(recon_id) + \
                                 ' where not(kickout)' + \
                                 ' LIMIT ' + str(end_point) + \
                                 ' OFFSET ' + str(start_point)
                    else:
                        view_query = 'SELECT * FROM fileService.view_bridge_' + str(recon_id) + \
                                 ' where not(kickout)' + \
                                 ' LIMIT ' + str(end_point) + \
                                 ' OFFSET ' + str(start_point)
                    response_data = get_view_data(view_query, app1_id, app2_id)

                else:
                    response_data = bridge_run
            else:
                response_data = is_valid
        else:
            if not (je_flag):
                response_data = {
                    'status': 6002,
                    'message': 'Please upload source file!'
                }
            else:
                response_data = {
                    'status': 200,
                    'message': ''
                }
    else:
        response_data = {

            'status': 403,
            'message': 'No recon found with the specified id!'

        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_kick_outs(request):

    # Getting the data from request
    recon_id = request.data['recon_id']
    je_flag = request.data['je_flag']

    # Checking if recon exists or not deleted
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        recon_data = get_recon(recon_id)
        recon_name = recon_data['name']
        app1_id = recon_data['app1_id']
        app2_id = recon_data['app2_id']

        # Getting both apps data
        if(je_flag):
            view_query = 'SELECT * FROM fileservice.view_bridge_je_' + str(recon_id) + \
                        '_kickout'

        else:
            view_query = 'SELECT * FROM fileservice.view_bridge_' + str(recon_id) + \
                        '_kickout'
        response_data = get_kick_out_view_data(view_query, app1_id, app2_id)

    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_kick_outs(request):

    # Getting the data from request
    recon_id = request.data['recon_id']
    kick_out_rows = request.data['rows']

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = update_outs(recon_id, kick_out_rows)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def kick_out_export(request):
    recon_id = request.data['recon_id']
    je_flag = request.data['je_flag']
    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Bridge_Kick_out_Export.csv'
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']
            # export_file = get_kick_out_export_data(recon_id)

            # Calling function for export query
            query = bridge_kick_out_query(recon_id, je_flag)

            # Calling the shell script to export to a csv file
            run_export_script(recon_id, file_name, query)

            if je_flag:
                file_name = "JE_" + file_name
            else:
                pass
            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))

            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response_data = HttpResponse(fh.read(), content_type="text/csv")
                    response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response_data

            else:
                response_data = {
                    'status': 6002,
                    'message': 'File Not Found'
                }

            # Setting the download response
            # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            # return response_data
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_kick_outs(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    file_obj = request.FILES['kick_out_file']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Getting file data
                response_data = get_import_kick_outs(recon_id, file_path)
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_bridge_export(request):
    recon_id = request.data['recon_id']
    je_flag = request.data['je_flag']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Run_bridge_Export.csv'
            # export_file = get_run_bridge_export_data(recon_id)

            # Calling function for export query
            query = run_bridge_export_query(recon_id, je_flag)

            run_export_script(recon_id,file_name,query)
            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))
            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
                    response['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    return response
            else:
                response_data = {
                    'status': 6002,
                    'message': 'File Not Found'
                }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_je_comments(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    file_obj = request.FILES['comments_file']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            # Storing file
            save_file = store_file(recon_id, file_obj)
            file_path = save_file[1]

            is_valid = is_valid_file(file_path)
            if is_valid['status'] == 200:
                # Getting file data
                response_data = get_import_comments(recon_id, file_path, True)
                response_data = add_comment_bridge_id(response_data)
            else:
                response_data = is_valid
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_update(request):
    # Getting the data from request
    recon_id = request.data['recon_id']
    comment_data = request.data['rows']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = update_comments(recon_id, comment_data, True)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_list(request, recon_id):
    if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        response_data = get_comments(recon_id, True)
    else:
        response_data = {
            'status': 403,
            'message': 'No recon found with the specified id!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_je_comment(request):
    recon_id = request.data['recon_id']
    bridge_id = request.data['bridge_id']
    app_type = request.data['app_type']

    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge_id)[0]
            instance.je_comment = None
            instance.save()

            response_data = {
                'status': 200,
                'message': 'Comment deleted successfully!'
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_export(request, recon_id):
    if is_write_permitted(request.user.email):
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'JE_Comments_Export.csv'
            export_file = get_comment_export_data(recon_id, True)

            # Setting the download response
            response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            return response_data

        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_bridge(request):
    recon_id = request.data['recon_id']
    bridge_id = request.data['bridge_id']

    if is_write_permitted(request.user.email):
        for bridge in bridge_id:
           if ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id= bridge).exists():
             instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge)
             instance.delete()

             response_data = {
                'status': 200,
                'message': 'Bridge deleted successfully!'
            }
           else:
             response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
             }
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def default_function(request):

    # Getting the data from request
    recon_id = request.data['recon_id']

    if is_write_permitted(request.user.email):
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            cursor = connections['Recon'].cursor()
            query = 'select * from fileservice.f_default_bridge_members(' + str(recon_id)+')'
            cursor.execute(query)

            response_data ={
               'status': 200,
               'message': "success..!"
                    }

        else:
            response_data = {

                'status': 403,
                'message': 'No recon found with the specified id!'

            }
    else:
        response_data = {
           'status': 6002,
           'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


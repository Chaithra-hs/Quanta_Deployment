from ..serializers import BridgeDimIdSerializer, DimIdSerializer
from ...models import ReconBridgeMapping, ReconDimensions


'''
<!---------- Method to check if all active dimensions
            have bridge configured except amount ----------!>
'''


def is_bridge_exists(recon_id):
    bridge_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, is_deleted=False, is_invalid=False)
    bridge_serialized = BridgeDimIdSerializer(bridge_instance, many=True)
    ordered_bridge_dim = bridge_serialized.data
    list_bridge_dim = []
    for dim in ordered_bridge_dim:
        dim_object = dict(dim)
        list_bridge_dim.append(dim_object['dim_id'])
    list_bridge_dim = list(set(list_bridge_dim))

    dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False, is_active=True)\
        .exclude(dimension='AMOUNT')
    dim_serialized = DimIdSerializer(dim_instance, many=True)
    ordered_dim = dim_serialized.data
    list_dim = []
    for dim in ordered_dim:
        dim_object = dict(dim)
        list_dim.append(dim_object['dimensions_id'])
    list_dim = list(set(list_dim))

    list_diff = list(set(list_dim).difference(list_bridge_dim))
    missing_dim = ""
    if list_diff:
        for dim in list_dim:
            missing_dim += get_dim_name(recon_id, dim) + ", "
        missing_dim = missing_dim[:-2]
        response_data = {
            'status': 6002,
            'message': 'Bridge not configured for ' + missing_dim + ' dimension.'
        }
    else:
        response_data = {
            'status': 200,
            'message': 'All dimensions are configured in bridge!'
        }

    return response_data


def get_dim_name(recon_id, dimensions_id):
    dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dimensions_id)[0]
    return dim_instance.dimension

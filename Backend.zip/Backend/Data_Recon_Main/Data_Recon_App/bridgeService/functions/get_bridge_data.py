from ... models import ReconBridgeMapping
from ..serializers import BridgeGetSerializer


'''
<!---------- Method to get the bridge data from db
             and return as structured data ----------!>
'''


def get_bridge_data(recon_id, app_type, res_tpe):
    if res_tpe == 'full':
        app1_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type='0', is_deleted=False)
        app2_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type='1', is_deleted=False)

        app1_serialized = BridgeGetSerializer(app1_instance, many=True)
        app2_serialized = BridgeGetSerializer(app2_instance, many=True)

        # Sorting rows
        # sorted_app1_rows = app1_serialized.data
        # sorted_app2_rows = app2_serialized.data
        # if sorted_app1_rows:
        #     sorted_app1_rows.sort(key=lambda x: int(x['dim_id']))
        # if sorted_app2_rows:
        #     sorted_app2_rows.sort(key=lambda x: int(x['dim_id']))

        response_data = {
            'status': 200,
            'recon_id': recon_id,
            'app1_rows': app1_serialized.data,
            'app2_rows': app2_serialized.data
        }
    else:
        app_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False)
        app_serialized = BridgeGetSerializer(app_instance, many=True)

        # Sorting rows
        # sorted_app_rows = app_serialized.data
        # if sorted_app_rows:
        #     sorted_app_rows.sort(key=lambda x: int(x['dim_id']))

        response_data = {
            'status': 200,
            'recon_id': recon_id,
            'app_type': app_type,
            'rows': app_serialized.data
        }

    return response_data

'''
<!---------- Method to get convert file data to save
             structure and save to db ----------!>
'''


def convert_bridge(file_data):
    number_of_bridges = len(file_data['rows'])
    for i in range(0, number_of_bridges):
        if file_data['rows'][i]['is_invalid']:
            file_data['rows'][i]['dim_id'] = None

    return file_data

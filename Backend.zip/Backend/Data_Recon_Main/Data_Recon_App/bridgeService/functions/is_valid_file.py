import csv


'''
<!---------- Method to check if the imported file
            is comma separated or not ----------!>
'''


def is_valid_file(file_path):
    with open(file_path, newline='') as csvfile:
        dialect = csv.Sniffer().sniff(csvfile.read())

    if dialect.delimiter == ',':
        delimiter_response = {
            'status': 200,
            'message': 'File is a valid comma separated file!'
        }
    else:
        delimiter_response = {
            'status': 6002,
            'message': 'Invalid file with ' + dialect.delimiter + ' as delimiter'
        }

    return delimiter_response

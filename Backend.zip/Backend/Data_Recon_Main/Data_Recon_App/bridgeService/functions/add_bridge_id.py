from ... models import ReconBridgeMapping
import random


'''
<!---------- Method to add bridge id in import
             structure and return response ----------!>
'''


def add_bridge_id(response_data):
    recon_id = response_data['recon_id']
    app_type = response_data['app_type']
    for i in range(0, len(response_data['rows'])):
        response_data['rows'][i]['bridge_id'] = get_bridge_id(recon_id, app_type, response_data['rows'][i])

    return response_data


def add_comment_bridge_id(response_data):
    recon_id = response_data['recon_id']
    for i in range(0, len(response_data['rows'])):
        if not response_data['rows'][i]['is_invalid']:
            if response_data['rows'][i]['app_type'] != 'BRIDGE':
                app_type = '0' if response_data['rows'][i]['app_type'] == 'APP1' else '1'
                response_data['rows'][i]['bridge_id'] = \
                    get_comment_bridge_id(recon_id, app_type, response_data['rows'][i])
                if not response_data['rows'][i]['bridge_id']:
                    response_data['rows'][i]['is_invalid'] = True
            else:
                response_data['rows'][i]['dim_id'] = response_data['rows'][i]['dim_id'][0]
                response_data['rows'][i]['bridge_id'] = \
                    get_bridge_comment_bridge_id(recon_id, response_data['rows'][i])
                if not response_data['rows'][i]['bridge_id']:
                    response_data['rows'][i]['is_invalid'] = True
        else:
            response_data['rows'][i]['bridge_id'] = random.randint(1, 999999)

    return response_data


def get_bridge_id(recon_id, app_type, data):
    if ReconBridgeMapping.\
        objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False,
                       source_member=data['source_member'], bridge_member=data['bridge_member']).exists():
        bridge_instance = ReconBridgeMapping.\
            objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False,
                           source_member=data['source_member'], bridge_member=data['bridge_member'])[0]
        return bridge_instance.bridge_id
    else:
        return None


def get_comment_bridge_id(recon_id, app_type, data):
    if ReconBridgeMapping.\
        objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False,
                       source_member=data['source_member'], dim_comment=data['comment'], dim_id=data['dim_id']).exists():
        bridge_instance = ReconBridgeMapping.\
            objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False,
                           source_member=data['source_member'], dim_comment=data['comment'], dim_id=data['dim_id'])[0]
        return bridge_instance.bridge_id
    else:
        return None


def get_bridge_comment_bridge_id(recon_id, data):
    if ReconBridgeMapping.\
        objects.filter(recon_id=recon_id, is_deleted=False,
                       bridge_member=data['source_member'], bridge_comment=data['comment'], dim_id=data['dim_id']).exists():
        bridge_instance = ReconBridgeMapping.\
            objects.filter(recon_id=recon_id, is_deleted=False,
                           bridge_member=data['source_member'], bridge_comment=data['comment'], dim_id=data['dim_id'])[0]
        return bridge_instance.bridge_id
    else:
        return None

from django.db import connections
import json


'''
<!---------- Method to do get view data and exclude
            some columns and return data as a response ----------!>
'''


def get_view_data(query, app1_id, app2_id):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]

        if 'kickout' in headers:
            headers.remove('kickout')

        if 'file_id' in headers:
            file_id_index = headers.index('file_id')
            headers.remove('file_id')

        if 'file_name' in headers:
            file_name_index = headers.index('file_name')
            headers.remove('file_name')

        headers = list(map(lambda x: x.replace('app_id', 'App1-App2'), headers))
        headers = list(map(lambda x: x.replace('AMOUNT-AMOUNT', 'Initial Amount'), headers))
        headers = list(map(lambda x: x.replace('user_comment', 'Comments'), headers))
        headers = list(map(lambda x: x.replace('je_comment', 'Journal Entry Comments'), headers))
        headers = list(map(lambda x: x.replace('sign_reversal_amount', 'Amounts with Sign Flips & App2 Reversals'), headers))
        amount_index = headers.index('Initial Amount')

        # Modified below code. For Journal Entries, the comments_index will be populated with 'Journal Entry Comments'
        # when headers.index('Comments') throws ValueError -- Anirudh
        try:
            comments_index = headers.index('Comments')
        except ValueError:
            comments_index = headers.index('Journal Entry Comments')
        
        reversal_index = headers.index('Amounts with Sign Flips & App2 Reversals')

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for result in results:
            result_list = list(result)
            if result_list[1] == app1_id:
                result_list[1] = 'App1'
            elif result_list[1] == app2_id:
                result_list[1] = 'App2'
            result_list.pop(0)
            result_list.pop(file_id_index)
            result_list.pop(file_name_index)

            # Re-formatting data
            result_list[amount_index] = "{:.2f}".format(float(result_list[amount_index]))
            result_list[reversal_index] = str(result_list[reversal_index])
            result_list[reversal_index] = "{:.2f}".format(float(result_list[reversal_index]))
            result_list[comments_index] = (result_list[comments_index]).split('^')

            # Converting back to tuple
            result = tuple(result_list)
            json_data.append(dict(zip(headers, result)))

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)


        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Data retrieved successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


def get_kick_out_view_data(query, app1_id, app2_id):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]
        headers = list(map(lambda x: x.replace('app_id', 'app1_app2'), headers))
        headers.append('out_id')

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for index, result in enumerate(results):
            result_list = list(result)
            if result_list[0] == app1_id:
                result_list[0] = 'App1'
            elif result_list[0] == app2_id:
                result_list[0] = 'App2'
            result_list.append(index)
            result = tuple(result_list)
            json_data.append(dict(zip(headers, result)))

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)

        response_data = {
            'status': 200,
            'rows': json_rows,
            'message': 'Data retrieved successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data

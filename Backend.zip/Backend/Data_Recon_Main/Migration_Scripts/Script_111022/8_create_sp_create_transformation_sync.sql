create or replace procedure fileservice.sp_create_transformation_sync(
	in recon_run_id integer
)
language 'plpgsql'
as $body$
declare
var_recon_id integer := recon_run_id;
s_schema_name text := 'fileservice';
var_bridge_name text := 'bridge_'||var_recon_id;
var_app1_id integer;
var_app2_id integer;
var_name text;
var_tfn record;
var_query text;

begin
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name
			into var_app1_id, var_app2_id, var_name
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	/*
	 * Create the dimension name combinations that will match with bridge- table column names
	 */

	for var_tfn in 
		select distinct q.recon_id, q.dim_id, q.tgt_concat_dimid, q.tgt_concat_dimname, q.concat_delimiter, string_agg(q.dim_name,'-') over(partition by dim_id) as c_dim_name
		from (
			select q1.recon_id, q1.dim_id, q1.tgt_concat_dimid, q1.tgt_concat_dimname, q1.concat_delimiter, q2.dim_name, q2.dim1_id, q2.dim2_id
			from (
				select rt.recon_id,rt.dim_id,rt.tgt_concat_dimid,rt.tgt_concat_dimname,rt.concat_delimiter,
				unnest(string_to_array(rt.tgt_concat_dimid,'-'))::integer as c_dim_id,
				unnest(string_to_array(rt.tgt_concat_dimname,'-')) as c_dim_name
				from fileservice.recon_transformation rt
				where rt.recon_id = var_recon_id----------------------------------------------------------------------------------------------------------------------------
			) q1
			inner join (
				select concat('"',rd1.dimension,'-',rd2.dimension,'"') as dim_name, rd1.dimensions_id as dim1_id, rd2.dimensions_id as dim2_id
				from fileservice.recon r
				inner join fileservice.recon_dimensions rd1
				on rd1.recon_id = r.recon_id
				and rd1.recon_app_id = r.app1_id 
				inner join fileservice.recon_dimensions rd2
				on rd2.recon_id = r.recon_id 
				and rd2.recon_app_id = r.app2_id 
				and rd1.turn_on_define_order = rd2.turn_on_define_order 
				where r.recon_id = var_recon_id----------------------------------------------------------------------------------------------------------------------------
			)q2
			on q1.c_dim_id in (q2.dim1_id, q2.dim2_id)
		)q
	loop 
--		raise notice '%', var_tfn;
	
		update fileservice.recon_transformation
		set bridge_concat_dim_name = var_tfn.c_dim_name
		where recon_id = var_tfn.recon_id
		and dim_id = var_tfn.dim_id
		and tgt_concat_dimid = var_tfn.tgt_concat_dimid;
	
	end loop;	

	--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Dimension name combinations updated''',
								var_recon_id::integer,
								'recon_transformation'
								);

	/*
	 * Create select query to pull from bridge table, recon_dimension, recon_transformation etc. to 
	 * get bridgesync view/ table
	 */
							
	select 
	concat('select app_id,',
	string_agg(concat(dim_name,',',case_stmt),', '),
	',',
	concat('coalesce(',coalesce(string_agg(flip_sign,'*'),'1'),',1)*sign_reversal_amount as "Amount-Amount", user_comment')) as stmt
	into var_query
	from (
		select
		distinct
		dimensions_id,
		concat('"',dim_name,'"') as dim_name,
		concat('coalesce(',
			case
				when tf_case::boolean
				then concat('case ',string_agg(case_stmt,' ') over (partition by dim_name),' else null end,')
				else null
			end,
			bridgesync_dimname,') as "bridgesync-',dim_name,'"') as case_stmt,
			case
				when tf_case::boolean
				then concat('case ',string_agg(flip_sign,' ') over (partition by dim_name),' else 1 end')
				else null
			end as flip_sign
		from (
			select
			dim_name,
			case
				when bridge_concat_dim_name is not null
				then true::boolean
				else false::boolean
			end as tf_case,	
			case
				when bridge_concat_dim_name is not null
				then concat('when app_id = ',app_id,' and concat(',regexp_replace(bridge_concat_dim_name,'"-"',concat('",''',delim,''',"')),') = ''',source_sync,''' then ''',target_sync,'''')
				else null
			end as case_stmt,
			case
				when bridge_concat_dim_name is not null
				then concat('when app_id = ',app_id,' and concat(',regexp_replace(bridge_concat_dim_name,'"-"',concat('",''',delim,''',"')),') = ''',source_sync,''' and ''',coalesce(flip_sign,false),'''::boolean then -1')
				else null
			end as flip_sign,
			concat('"bridge-',dim_name,'"') as bridgesync_dimname,
			dimensions_id
			from (
				select r.recon_id, coalesce(q.app_id,rd1.recon_app_id, rd2.recon_app_id) as app_id, concat(rd1.dimension,'-',rd2.dimension) as dim_name,
				rd1.dimensions_id , q.bridge_concat_dim_name, q.source_sync, q.target_sync, coalesce(q.concat_delimiter,'-')::text as delim, q.flip_sign 
				from fileservice.recon r 
				inner join fileservice.recon_dimensions rd1
				on r.recon_id = rd1.recon_id 
				and r.app1_id = rd1.recon_app_id 
				inner join fileservice.recon_dimensions rd2
				on r.recon_id = rd2.recon_id 
				and r.app2_id = rd2.recon_app_id 
				and rd1.turn_on_define_order = rd2.turn_on_define_order 
				left join(
					select rt.recon_id, rto.app_id, rt.dim_id , rt.bridge_concat_dim_name, rto.source_sync, rto.target_sync,  rt.concat_delimiter,
					rto.flip_sign 
					from fileservice.recon_transformation rt 
					inner join fileservice.recon_transformation_override rto
					on rt.recon_id = rto.recon_id 
					and rt.id = rto.tfn_id
					where rt.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
					and rt.apply_all_members
				)q
				on r.recon_id = q.recon_id
				and q.app_id in (r.app1_id, r.app2_id)
				and q.dim_id in (rd1.dimensions_id, rd2.dimensions_id)
				where r.recon_id = var_recon_id------------------------------------------------------------------------------------------------------------------------------------------
				and rd1.dimension <> 'Amount'
				order by rd1.dimensions_id
			) qry
			order by dimensions_id 
		) qry1
		order by dimensions_id
	)qry2;

	/*
	 * Drop and create bridgesync view using the query generated above
	 * 
	 */
	var_query = var_query||' from '||s_schema_name||'.'||'bridge_'||var_recon_id;
	var_query = 'drop view if exists '||s_schema_name||'.'||'view_bridgesync_'||var_recon_id||' cascade; create or replace view '||s_schema_name||'.'||'view_bridgesync_'||var_recon_id||' as ('||var_query||');';
--raise notice '%', var_query;

	execute var_query;

	--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Bridge Sync view view_bridgesync_'|| var_recon_id || ' created'''::text,
								var_recon_id::integer,
								'view_bridgesync_'||var_recon_id::text
								);

end;
$body$

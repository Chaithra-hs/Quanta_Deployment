create or replace procedure fileservice.sp_create_recon_run_bridge_table(
	in recon_id integer
)
language 'plpgsql'
as $body$
declare
s_schema_name text := 'fileservice';
var_recon_id integer := recon_id;
var_app1_id integer := 0;

var_app2_id integer := 0;

var_name text := '';
var_name_table text := '';

var_view_script text := '';
var_script text := '';
var_kickout boolean := false;

begin
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name
			into var_app1_id, var_app2_id, var_name
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	var_name_table = var_name;

--	raise notice '%-%-%',var_app1_id, var_app2_id, var_view_name;

	/*
	 * Create the bridge view script
	 * 
	 */
	select
	concat('select case when ''kickout'' in (', string_agg(dim_name, ', '), ') then true else false end as kickout, * from (') as stmt
	into var_view_script
	from
		(
		select 
			concat('"bridge-', rd1.dimension, '-', rd2.dimension, '"')::text as dim_name
		from fileservice.recon r
		inner join fileservice.recon_dimensions rd1
		on r.app1_id = rd1.recon_app_id
		and rd1.is_active 
		inner join fileservice.recon_dimensions rd2
		on rd1.turn_on_define_order = rd2.turn_on_define_order
		and r.app2_id = rd2.recon_app_id
		and rd2.is_active 
		inner join fileservice.recon_bridge_mapping rbm 
		on r.recon_id = rbm.recon_id
		and not rbm.is_deleted 
		and not rbm.is_invalid 
		and (rd1.dimensions_id = rbm.dim_id or rd2.dimensions_id = rbm.dim_id)
		where r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
		group by
			rd1.dimensions_id ,
			rd2.dimensions_id
		order by
			rd1.turn_on_define_order 
		)q1;


	select concat('select app_id, ' , string_agg(col,', '),', "Amount-Amount"::decimal, case when app_id%2=0 then -1 else 1 end *', string_agg(flip_sign,''),'*"Amount-Amount"::decimal as sign_reversal_amount, file_name, file_id, ', string_agg(com,',')) as col_list
	into var_script
	from (
		select
		string_agg(concat(src_col,', ',bridge_col),', ') as col,
		concat(string_agg(concat(dim_comment,'||''^''||',bridge_comment),'||''^''||'),' as user_comment') as com,
		string_agg(flip_sign,'*') as flip_sign
		from (
			select 
			distinct
			dimensions_id,
			concat('"',dim_name,'"') as src_col, 
			concat('case ',string_agg(case_stmt,' ') over (partition by dim_name order by dimensions_id),' else ''kickout'' end as "bridge-',dim_name,'"') as bridge_col,
			concat('case ',string_agg(dim_comment,' ') over (partition by dim_name order by dimensions_id),' else null end') as dim_comment,
			concat('case ',string_agg(bridge_comment,' ') over (partition by dim_name order by dimensions_id),' else null end') as bridge_comment,
			concat('case ',string_agg(flip_sign,' ') over (partition by dim_name order by dimensions_id),' else 1 end') as flip_sign
			from (
				select 
				rd1.dimensions_id,
				rd1.turn_on_define_order,
				concat(rd1.dimension,'-',rd2.dimension)::text as dim_name,
				concat('when app_id=',rbm.app_id,' and trim(lower("',rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''',rbm.source_member,''')) then ''',rbm.bridge_member,'''') as case_stmt,
				concat('when app_id=',rbm.app_id,' and trim(lower("',rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''',rbm.source_member,''')) then ''',rbm.dim_comment,'''') as dim_comment,
				concat('when app_id=',rbm.app_id,' and trim(lower("',rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''',rbm.source_member,''')) then ''',rbm.bridge_comment,'''') as bridge_comment,
				concat('when app_id=',rbm.app_id,' and trim(lower("',rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''',rbm.source_member,''')) and ''',rbm.flip_sign,'''::boolean then -1') as flip_sign
				from fileservice.recon r 
				inner join fileservice.recon_dimensions rd1
				on r.app1_id  = rd1.recon_app_id 
				and rd1.is_active
				inner join fileservice.recon_dimensions rd2
				on rd1.turn_on_define_order = rd2.turn_on_define_order 
				and r.app2_id = rd2.recon_app_id
				and rd2.is_active
				inner join fileservice.recon_bridge_mapping rbm 
				on r.recon_id = rbm.recon_id 
				and (rd1.dimensions_id=rbm.dim_id or rd2.dimensions_id=rbm.dim_id)
				and not rbm.is_deleted
				and not rbm.is_invalid 
				where r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
				order by rd1.dimensions_id, rd1.turn_on_define_order, rd2.turn_on_define_order
			) q1
			order by dimensions_id
		) q2
		/*
		 * removing as amount-amount column is hard-coded in the above part of the query
		union all 
		select 
			concat('"',rd1.dimension,'-',rd2.dimension,'"') as col,
			null as com,
			null as flip_sign
			from fileservice.recon r 
			inner join fileservice.recon_dimensions rd1
			on r.app1_id  = rd1.recon_app_id 
			inner join fileservice.recon_dimensions rd2
			on rd1.turn_on_define_order = rd2.turn_on_define_order 
			and r.app2_id = rd2.recon_app_id
			left join fileservice.recon_bridge_mapping rbm2 
			on r.recon_id = rbm2.recon_id 
			and (rd1.dimensions_id=rbm2.dim_id or rd2.dimensions_id=rbm2.dim_id)
			where r.recon_id = 1----------------------------------------------------------------------------------------------------------------- 
			and (rd1.dimensions_id, rd2.dimensions_id ) not in (select 
					rd3.dimensions_id ,rd4.dimensions_id 
					from fileservice.recon r2 
					inner join fileservice.recon_dimensions rd3
					on r2.app1_id  = rd3.recon_app_id 
					inner join fileservice.recon_dimensions rd4
					on rd3.turn_on_define_order = rd4.turn_on_define_order 
					and r2.app2_id = rd4.recon_app_id
					inner join fileservice.recon_bridge_mapping rbm 
					on r2.recon_id = rbm.recon_id 
					and (rd3.dimensions_id=rbm.dim_id or rd4.dimensions_id=rbm.dim_id)
					where r2.recon_id = 1-------------------------------------------------------------------------------
					order by rd3.turn_on_define_order
					)*/
	) q3;

	/*
	 * Execute the create bridge view script
	 * 
	 */
	var_view_script = 'drop view if exists '||s_schema_name||'.view_bridge_'||var_name||' cascade; create or replace view '||s_schema_name||'.view_bridge_'||var_name|| ' as ('||var_view_script||var_script||' from '||s_schema_name||'.view_'||var_name||') q1 );';


--	raise notice '%',var_view_script;
	execute var_view_script;
	var_name = 'view_bridge_'||var_name;

	--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Bridge view '|| var_name || ' created'''::text,
								var_recon_id::integer,
								var_name::text
								);
	
	/*
	 * Bridge Kickouts view
	 * 
	 */
							
	select concat('select app_id, source_member, file_name from ( select distinct app_id, unnest(string_to_array(concat( ',string_agg(source_member,', '),'), '' '')) as source_member, file_name from ')
	into var_script
	from (
		select 
		distinct
		concat('case when "bridge-',rd1.dimension,'-',rd2.dimension,'"=''kickout''::text then "',rd1.dimension,'-',rd2.dimension,'" end, '' ''') as source_member
		from fileservice.recon r 
		inner join fileservice.recon_dimensions rd1
		on r.app1_id  = rd1.recon_app_id 
		and rd1.is_active 
		inner join fileservice.recon_dimensions rd2
		on rd1.turn_on_define_order = rd2.turn_on_define_order 
		and rd2.is_active 
		and r.app2_id = rd2.recon_app_id
		inner join fileservice.recon_bridge_mapping rbm 
		on r.recon_id = rbm.recon_id
		and not rbm.is_deleted 
		and not rbm.is_invalid 
		and (rd1.dimensions_id=rbm.dim_id or rd2.dimensions_id=rbm.dim_id)
		where r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
	) q1;

	var_script = var_script||s_schema_name||'.'||var_name||' where kickout ) q1 where source_member<>''''';
--	raise notice '%', var_script;

	var_view_script = 'create or replace view '||s_schema_name||'.'||var_name||'_kickout as ('||var_script||' );';

--	raise notice '%',var_view_script;
	execute var_view_script;

	var_name = var_name||'_kickout';

	--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Bridge view '|| var_name || ' created'''::text,
								var_recon_id::integer,
								var_name::text
								);
	
	/*
	 * If no kickouts convert the bridge view into a table for further process
	 */
	execute 'select not exists (select * from fileservice.'||var_name||')' into var_kickout;

	if var_kickout
		then
		var_script = 'drop table if exists '||s_schema_name||'.bridge_'||var_name_table||' cascade; create table '||s_schema_name||'.bridge_'||var_name_table;
		var_script = var_script || ' as select * from '||s_schema_name||'.view_bridge_'||var_name_table||';';
		execute var_script;	
		--	 Log Script
		
		call fileService.sp_log_entry(
									null::integer,
									'''Bridge table bridge_'|| var_name_table || ' created'''::text,
									var_recon_id::integer,
									var_name::text
									);
		
		update fileservice.recon r
		set status = 'Bridged'
		where r.recon_id = var_recon_id;
	else
	
		call fileService.sp_log_entry(
									null::integer,
									'''Kickouts exist for view view_'|| var_name_table || '.'''::text,
									var_recon_id::integer,
									var_name::text
									);
		
		update fileservice.recon r
		set status = 'Kickouts'
		where r.recon_id = var_recon_id;
	end if;

								
							
end;
$body$

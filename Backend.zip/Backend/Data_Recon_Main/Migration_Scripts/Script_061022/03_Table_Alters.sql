ALTER TABLE IF EXISTS fileservice.recon_applications
    ADD COLUMN currency_symbol "char";

ALTER TABLE IF EXISTS fileservice.recon_applications
    ADD COLUMN currency_delimiter "char";

-- SEQUENCE: fileservice.recon_bridge_mapping_id_seq

DROP SEQUENCE IF EXISTS fileservice.recon_bridge_mapping_id_seq cascade;

CREATE SEQUENCE fileservice.recon_bridge_mapping_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_bridge_mapping_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_bridge_mapping_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_bridge_mapping_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_bridge_mapping

DROP TABLE  IF EXISTS fileservice.recon_bridge_mapping cascade;

CREATE TABLE IF NOT EXISTS fileservice.recon_bridge_mapping
(
    bridge_id bigint NOT NULL DEFAULT nextval('fileservice.recon_bridge_mapping_id_seq'::regclass),
    recon_id bigint,
    app_id bigint,
    dim_id bigint,
    flip_sign boolean,
    app_type character varying COLLATE pg_catalog."default",
    source_member character varying COLLATE pg_catalog."default",
    bridge_member character varying COLLATE pg_catalog."default",
    dim_comment character varying COLLATE pg_catalog."default",
    is_deleted boolean,
    bridge_comment character varying COLLATE pg_catalog."default",
    is_invalid boolean,
    CONSTRAINT pk_recon_bridge_mapping PRIMARY KEY (bridge_id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_bridge_mapping
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.recon_bridge_mapping TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_bridge_mapping TO "user_dataRecon_file";
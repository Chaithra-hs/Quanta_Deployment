DROP SEQUENCE IF EXISTS fileservice.track_app_data_table_id_seq cascade;

CREATE SEQUENCE fileservice.track_app_data_table_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE fileservice.track_app_data_table_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_app_data_table_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_app_data_table_id_seq TO "user_dataRecon_file";

-- Table: fileservice.track_app_data_table

DROP TABLE IF EXISTS fileservice.track_app_data_table cascade;

CREATE TABLE fileservice.track_app_data_table
(
    id integer NOT NULL DEFAULT nextval('fileservice.track_app_data_table_id_seq'::regclass),
    recon_id bigint,
    application_id bigint,
    table_name character varying COLLATE pg_catalog."default",
    log_comment character varying COLLATE pg_catalog."default" NOT NULL,
	source_caller character varying COLLATE pg_catalog."default",
    user_email character varying COLLATE pg_catalog."default",
	created_date timestamp without time zone NOT NULL,
    CONSTRAINT pk_track_app_data_id PRIMARY KEY (id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.track_app_data_table
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.track_app_data_table TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_app_data_table TO "user_dataRecon_file";
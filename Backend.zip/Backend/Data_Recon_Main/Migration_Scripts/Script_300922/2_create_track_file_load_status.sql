-- SEQUENCE: fileservice.track_file_load_status_file_id_seq

DROP SEQUENCE IF EXISTS fileservice.track_file_load_status_file_id_seq CASCADE;

CREATE SEQUENCE fileservice.track_file_load_status_file_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.track_file_load_status_file_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_file_load_status_file_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_file_load_status_file_id_seq TO "user_dataRecon_file";

-- Table: fileservice.track_file_load_status

DROP TABLE IF EXISTS fileservice.track_file_load_status CASCADE;

CREATE TABLE fileservice.track_file_load_status
(
    file_id bigint NOT NULL DEFAULT nextval('fileservice.track_file_load_status_file_id_seq'::regclass),
    recon_id bigint,
    app_id bigint,
    file_location character varying COLLATE pg_catalog."agq-CM-x-icu",
    file_name character varying COLLATE pg_catalog."default" NOT NULL,
    status character varying COLLATE pg_catalog."default",
	created_date timestamp without time zone NOT NULL,
    CONSTRAINT track_file_load_status_pkey PRIMARY KEY (file_id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.track_file_load_status
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.track_file_load_status TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_file_load_status TO "user_dataRecon_file";
-- If any of the script throwing error like column already exists
-- Please ignore that script

GRANT pg_read_server_files TO "user_dataRecon_file";

ALTER TABLE IF EXISTS fileservice.recon_bridge_mapping
    RENAME comment TO dim_comment;

ALTER TABLE IF EXISTS fileservice.recon_bridge_mapping
    ADD COLUMN bridge_comment character varying;

ALTER TABLE IF EXISTS fileservice.recon_dimensions
    ADD COLUMN recon_app_id bigint;
DROP SEQUENCE IF EXISTS fileservice.track_app_data_table_id_seq cascade;

CREATE SEQUENCE fileservice.track_app_data_table_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;

ALTER SEQUENCE fileservice.track_app_data_table_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_app_data_table_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_app_data_table_id_seq TO "user_dataRecon_file";

-- Table: fileservice.track_app_data_table

DROP TABLE IF EXISTS fileservice.track_app_data_table cascade;

CREATE TABLE fileservice.track_app_data_table
(
    id integer NOT NULL DEFAULT nextval('fileservice.track_app_data_table_id_seq'::regclass),
    recon_id bigint,
    application_id bigint,
    table_name character varying COLLATE pg_catalog."default",
	table_status character varying collate pg_catalog."default" NOT NULL,
    created_date timestamp without time zone NOT NULL,
    CONSTRAINT pk_track_app_data_id PRIMARY KEY (id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.track_app_data_table
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.track_app_data_table TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_app_data_table TO "user_dataRecon_file";


-- SEQUENCE: fileservice.track_file_load_status_file_id_seq

DROP SEQUENCE IF EXISTS fileservice.track_file_load_status_file_id_seq CASCADE;

CREATE SEQUENCE fileservice.track_file_load_status_file_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.track_file_load_status_file_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_file_load_status_file_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.track_file_load_status_file_id_seq TO "user_dataRecon_file";

-- Table: fileservice.track_file_load_status

DROP TABLE IF EXISTS fileservice.track_file_load_status CASCADE;

CREATE TABLE fileservice.track_file_load_status
(
    file_id bigint NOT NULL DEFAULT nextval('fileservice.track_file_load_status_file_id_seq'::regclass),
    recon_id bigint,
    app_id bigint,
    file_location character varying COLLATE pg_catalog."agq-CM-x-icu",
    file_name character varying COLLATE pg_catalog."default" NOT NULL,
    status character varying COLLATE pg_catalog."default",
	created_date timestamp without time zone NOT NULL,
    CONSTRAINT track_file_load_status_pkey PRIMARY KEY (file_id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.track_file_load_status
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.track_file_load_status TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_file_load_status TO "user_dataRecon_file";


CREATE OR REPLACE PROCEDURE fileService.sp_create_dynamic_table(
	in recon_app_id integer
)
LANGUAGE 'plpgsql'
AS $BODY$
DECLARE
var_app_id integer := recon_app_id;
var_script varchar := '';
var_dim_name text := '';
v_dim_name_rec record;
var_table_rec record;
s_schema_name text := 'fileservice';
begin

-- If the recon application id exists, then fetch it's corresponding dimensions
if
		exists(select count(*) from fileservice.recon_dimensions rd where rd.recon_app_id = var_app_id)
	then
--		raise notice '1';

		select concat(string_agg(dim,', '),', file_name character varying COLLATE pg_catalog."default", file_id integer')
		into var_dim_name
		from (
			select concat(dim,' character varying COLLATE pg_catalog."default"') as dim
			from (
				select rd.dimension as dim
				from fileservice.recon_dimensions rd
				where rd.recon_app_id = var_app_id
				order by rd.dimensions_id
			) q1
		) q2;
--		raise notice '%', var_dim_name;

	-- Preparation of the create table script
		select concat('app_',var_app_id,'_', r."name" ) as table_name, r.recon_id as rec_id
		into var_table_rec
		from fileservice.recon r
		where r.app1_id = var_app_id
		or r.app2_id = var_app_id;

		var_script = 'Drop table if exists '||s_schema_name||'.'||var_table_rec.table_name||' cascade;';
		var_script = var_script ||' Create table if not exists '||s_schema_name||'.'||var_table_rec.table_name||' ( app_id integer null default '||var_app_id||', '||var_dim_name||' ) TABLESPACE tbsp_data_recon;';

	-- Adding permissions to the table
		var_script = var_script ||' GRANT ALL ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO postgres;';
		var_script = var_script ||' GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO "user_dataRecon_file";';

--		raise notice '%',var_script;

	-- Run create table script
	execute var_script;

	-- Log Script
	call fileService.sp_log_entry(
								var_app_id::integer,
								'''Table created'''::text,
								var_table_rec.rec_id::integer,
								var_table_rec.table_name::text
								);

	end if;

END
$BODY$;


CREATE OR REPLACE PROCEDURE fileService.sp_load_dynamic_table(
	in recon_app_id integer
)
LANGUAGE 'plpgsql'
AS $BODY$
DECLARE
var_app_id integer = recon_app_id;
var_table_name record;
var_table boolean := false;

var_script text := '';
var_script_insert text := '';

var_dim_names text[];
v_dim text := '';
var_file record;
var_default_location text := 'C:\Workspace\PostgreSQL\Data_Recon\input\';
var_file_meta record;
s_schema_name text := 'fileservice';
v_row_count integer :=0;
v_file_count integer :=0;
v_tmp_table text := '';


begin

	call fileservice.sp_log_entry(var_app_id, '''Preparing load''');

	/*
	 * This procedure assumes that the target table exists on the database with appropriate roles and privileges
	 *
	 * Check if the application entry exists in the recon_application table
	 */
	if
		exists(select 1 from fileservice.recon_applications ra where ra.recon_app_id=var_app_id)
		then
			select concat('app_',var_app_id,'_', r."name" ) as table_name, r.recon_id::integer as rec_id
			into var_table_name
			from fileservice.recon r
			where r.app1_id = var_app_id
			or r.app2_id = var_app_id;
		else
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Application does not exist'''::text
									);
			return;
	end if;

	v_tmp_table = var_table_name.table_name||'_tmp';


	/*
	 * Check if the table exists in the database using the system table pg_catalog.pg_tables
	 */
	select exists
	into var_table
	(select from pg_catalog.pg_tables pt
	where schemaname = s_schema_name
	and tablename = var_table_name.table_name) q1;
--	raise notice '%', not(var_table);

	if not(var_table)
		then
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Table does not exist'''::text
									);
			return;
--			raise exception '% table does not exist',var_table_name;
	end if;


	/*
	 * Prepare the copy statement to load the file
	 * Loop to get the dimension names that exist in the file
	 *
	 */
	var_dim_names := array (
			select concat('"',generate_series(1,v_max),'"') as col_id
			from (
				select max(type_field::integer) as v_max
				from fileservice.recon_dimensions rd
				where rd.recon_app_id = var_app_id
				and top_member is null
			) q2
	);


	/*
	 * Create intermediate temp table
	 */
	var_script = 'drop table if exists fileservice.'||v_tmp_table||' cascade; ';
	var_script = var_script || 'create table fileservice.'||v_tmp_table||'( ';

	foreach v_dim in array var_dim_names
	loop
		var_script = var_script || v_dim || '  character varying COLLATE pg_catalog."default",';
	end loop;

	var_script = var_script || ' dummy_column character varying COLLATE pg_catalog."default") TABLESPACE tbsp_data_recon;';
	execute var_script;

	/*
	 * v_dim will provide dimension names for file to temp table
	 */
	v_dim = pg_catalog.array_to_string(var_dim_names, ',') ;


	var_script_insert = 'insert into '||s_schema_name||'.'||var_table_name.table_name||' (';
	select
		string_agg(dim_name,', ')
	into var_script
	from (
		select rd.dimension as dim_name
		from fileservice.recon_dimensions rd
		where rd.recon_app_id = var_app_id
		order by rd.type_field::integer,
		rd.dimensions_id
	) q3;
	var_script_insert = var_script_insert||var_script||')';


	select concat('select ',string_agg(dim_name,', '))
	into var_script
	from (
		select
			case
				when rd.type_field is null
				then concat('''',rd.top_member,'''')
				else concat('"',rd.type_field,'"')
			end as dim_name
		from fileservice.recon_dimensions rd
		where rd.recon_app_id = var_app_id
		order by rd.type_field::integer,
		rd.dimensions_id
	) q4;

	var_script = var_script || ' from '||s_schema_name||'.'||v_tmp_table;

	var_script_insert = var_script_insert||' '||var_script;
--	raise notice '%', var_script_insert;


	select import_delimiter ,
	case
		when has_header=true
		then 'csv header'
		else ''
		end as import_header
	into var_file_meta
	from fileservice.recon_applications ra
	where ra.recon_app_id = var_app_id;



	for var_file in
		select --concat('''',coalesce(tfls.file_location, var_default_location) , tfls.file_name,'''') as file
		tfls.file_location as file_location , tfls.file_name as file
		from fileservice.track_file_load_status tfls
		where tfls.app_id = var_app_id
		and (tfls.status <> 'Completed'
		or tfls.status is null)
		order by tfls .file_id
	loop

		/*
		 * log file load start time
		 */
		call fileservice.sp_log_entry(
			var_app_id,
			'''Loading file '||var_file.file||'''',
			var_table_name.rec_id,
			var_table_name.table_name
		);

		var_script = 'delete from '||s_schema_name||'.'||v_tmp_table;
		execute var_script;


		/*
		 * load file to tmp table
		 */
		var_script = 'copy '||s_schema_name||'.'||v_tmp_table||'('|| v_dim ||') from ';
		var_script = var_script||''''||var_file.file_location||var_file.file||'''';
		var_script = var_script|| ' delimiter '''||var_file_meta.import_delimiter||''' '||var_file_meta.import_header||';';
--		raise notice '%',var_script;
		execute var_script;

		get diagnostics v_row_count = ROW_COUNT;
		v_file_count = v_file_count+1;


		/*
		 * Move data from tmp table to dynamic table
		 */
		execute var_script_insert;

		--log file status
		update fileservice.track_file_load_status
		set status = 'Completed'
		where app_id = var_app_id
		and file_name = var_file.file;
--		perform pg_sleep(5);

		/*
		 * log file load end time
		 */
		call fileservice.sp_log_entry(
			var_app_id,
			'''Load completed for file '||var_file.file||' '||v_row_count||' rows''',
			var_table_name.rec_id,
			var_table_name.table_name
		);

		commit;

	end loop;


	/*
	 * Log final load status
	 */
	call fileservice.sp_log_entry(
		var_app_id,
		'''Load completed for '||v_file_count||' files''',
		var_table_name.rec_id,
		var_table_name.table_name
	);

END
$BODY$;





create or replace
procedure fileservice.sp_log_entry(
in app_id integer,
in status text,
in recon_id integer default null,
in table_name text default null
)
language 'plpgsql'
as $BODY$
declare
s_schema_name text := 'fileservice';
s_tracker_table text := 'track_app_data_table';
var_script text := '';
begin

	if (recon_id is null) and (table_name is null)
		then
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (application_id, table_status, created_date)';
			var_script = var_script || 'values (' || app_id || ',' || status || ',''' ||localtimestamp||'''::timestamp);';
		else
			var_script = 'insert into ' || s_schema_name || '.' || s_tracker_table || ' (recon_id, application_id, table_name, table_status, created_date)';
			var_script = var_script || ' values (' || recon_id || ',' || app_id || ',''' || table_name || ''', '||status||',''' || localtimestamp || '''::timestamp);';
	end if;

--	raise notice '%', var_script;
-- Run insert into trakcer table
	execute var_script;
	commit;
end;

$BODY$

-- 01/09/2022 DB Migrations

ALTER TABLE IF EXISTS fileservice.recon
ADD COLUMN is_deleted boolean;

ALTER TABLE IF EXISTS fileservice.recon
ADD COLUMN dimensions_id bigint;

ALTER TABLE IF EXISTS fileservice.recon
DROP COLUMN dimensions;


CREATE SEQUENCE fileservice.recon_dimensions_dimensions_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_dimensions_dimensions_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_dimensions_dimensions_id_seq TO postgres;
GRANT ALL ON SEQUENCE fileservice.recon_dimensions_dimensions_id_seq TO "user_dataRecon_file";

CREATE TABLE fileservice.recon_dimensions
(
    dimensions_id bigint NOT NULL DEFAULT nextval('fileservice.recon_dimensions_dimensions_id_seq'::regclass),
    turn_on_define_order VARCHAR,
    dimension VARCHAR,
    dim_in_file boolean,
    type_field VARCHAR,
    top_member VARCHAR,
    app_type VARCHAR,
    recon_id bigint,
    is_deleted boolean,
    CONSTRAINT pk_dimensions_id PRIMARY KEY (dimensions_id)
        USING INDEX TABLESPACE tbsp_data_recon
)
TABLESPACE tbsp_data_recon;

ALTER TABLE IF EXISTS fileservice.recon
ALTER COLUMN created_date TYPE timestamp without time zone
USING current_date + created_date;

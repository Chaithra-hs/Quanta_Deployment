-- 02/09/2022 DB Migrations

CREATE SEQUENCE fileservice.recon_bridge_members_bridge_member_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_bridge_members_bridge_member_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_bridge_members_bridge_member_id_seq TO postgres;
GRANT ALL ON SEQUENCE fileservice.recon_bridge_members_bridge_member_id_seq TO "user_dataRecon_file";

CREATE TABLE fileservice.recon_bridge_members
(
    bridge_member_id bigint NOT NULL DEFAULT nextval('fileservice.recon_bridge_members_bridge_member_id_seq'::regclass),
	dimensions_id bigint,
	source_member character varying,
	flip_sign boolean,
	bridge_member character varying,
	recon_id bigint,
	created_by character varying,
    created_date time without time zone,
	is_deleted boolean,
    CONSTRAINT pk_bridge_member_id PRIMARY KEY (bridge_member_id)
        USING INDEX TABLESPACE tbsp_data_recon
)
TABLESPACE tbsp_data_recon;

ALTER TABLE IF EXISTS fileservice.recon
    ADD COLUMN description character varying;
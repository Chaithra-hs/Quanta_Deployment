ALTER TABLE IF EXISTS fileservice.recon
    ADD COLUMN app1_source_file character varying;

ALTER TABLE IF EXISTS fileservice.recon
    ADD COLUMN app2_source_file character varying;
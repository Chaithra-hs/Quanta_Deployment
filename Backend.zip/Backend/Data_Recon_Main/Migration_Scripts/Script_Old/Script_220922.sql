-- SEQUENCE: fileservice.recon_recon_id_seq

DROP SEQUENCE fileservice.recon_recon_id_seq cascade;

CREATE SEQUENCE fileservice.recon_recon_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_recon_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_recon_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_recon_id_seq TO "user_dataRecon_file";

-- Table: fileservice.recon

DROP TABLE fileservice.recon cascade;

CREATE TABLE fileservice.recon
(
    recon_id bigint NOT NULL DEFAULT nextval('fileservice.recon_recon_id_seq'::regclass),
    app1_id bigint,
    app2_id bigint,
    name character varying COLLATE pg_catalog."default",
    variance_threshold bigint,
    execution_date time without time zone,
    status character varying COLLATE pg_catalog."default",
    is_deleted boolean,
    description character varying COLLATE pg_catalog."default",
	created_by character varying COLLATE pg_catalog."default",
    created_date timestamp without time zone,
    last_modified_by character varying COLLATE pg_catalog."default",
    last_modified_date timestamp without time zone,
    CONSTRAINT pk_recon_id PRIMARY KEY (recon_id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.recon TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon TO "user_dataRecon_file";


-- SEQUENCE: fileservice.recon_applications_recon_app_id_seq

DROP SEQUENCE fileservice.recon_applications_recon_app_id_seq cascade;

CREATE SEQUENCE fileservice.recon_applications_recon_app_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_applications_recon_app_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_applications_recon_app_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_applications_recon_app_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_applications

DROP TABLE fileservice.recon_applications cascade;

CREATE TABLE fileservice.recon_applications
(
    recon_app_id bigint NOT NULL DEFAULT nextval('fileservice.recon_applications_recon_app_id_seq'::regclass),
	recon_id bigint,
    app_name character varying COLLATE pg_catalog."default",
    import_type character varying COLLATE pg_catalog."default",
    import_delimiter character varying COLLATE pg_catalog."default",
	has_header boolean,
    url character varying COLLATE pg_catalog."default",
    cube character varying COLLATE pg_catalog."default",
    username character varying COLLATE pg_catalog."default",
    password character varying COLLATE pg_catalog."default",
	filename character varying COLLATE pg_catalog."default",
	is_deleted boolean,
    CONSTRAINT pk_recon_app_id PRIMARY KEY (recon_app_id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_applications
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.recon_applications TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_applications TO "user_dataRecon_file";
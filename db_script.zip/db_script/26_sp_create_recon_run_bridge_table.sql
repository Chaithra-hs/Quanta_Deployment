CREATE OR REPLACE PROCEDURE fileservice.sp_create_recon_run_bridge_table(recon_id integer, journal_entry boolean DEFAULT false)
 LANGUAGE plpgsql
AS $procedure$
declare
var_recon_id int := recon_id;
var_je bool := journal_entry;
var_app_id integer := 0;
var_app1_id integer := 0;
var_app2_id integer := 0;
var_script text := '';
var_script2 text := '';
var_col_list text := '';
var_app_type int := 0;
var_name text := '';
var_name_table text := '';
var_view_script text := '';
s_schema_name text := 'fileservice';
var_kickout boolean := false;
begin
	/*
	 * if active get the individual application id that belong to the recon id
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name
			into var_app1_id, var_app2_id, var_name
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;
	/*
	 * Check if recon is not signed-off
	 */
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
		-- Log Script
		call fileService.sp_log_entry(
								NULL::integer,
								'''ERROR: Recon is signed-off'''::text,
								var_recon_id,
								NULL::text
								);
			return;		
	end if;
	/*
	 * Modify view name as per Journal Entry flag
	 */
	IF (var_je)
	THEN 
		var_name = 'je_'||var_name;
		var_name_table = var_name;
	ELSE
		var_name_table = var_name;
	END IF;

	execute 'drop table if exists fileservice.bridge_'||var_recon_id||'_tmp cascade;';
	select 
	'create table if not exists '||s_schema_name||'.bridge_'||var_recon_id||'_tmp ( app_id int not null, '||string_agg('"'||dim_name||' varchar NULL, "bridge-'||dim_name||' varchar NULL',',')||', "AMOUNT-AMOUNT" decimal, sign_reversal_amount decimal, file_name varchar NULL, file_id int NULL, user_comment varchar NULL, je_comment varchar NULL) tablespace tbsp_data_recon;' as var_script
	, '( app_id, '||string_agg('"'||dim_name||', "bridge-'||dim_name,',')||', "AMOUNT-AMOUNT", sign_reversal_amount, file_name, file_id , user_comment, je_comment )' as var_col_list
	into var_script2, var_col_list
	from (
		select ''||rd1.dimension||'-'||rd2.dimension||'"' as dim_name, rd1.recon_id, rd1.recon_app_id
		from fileservice.recon_dimensions rd1
		inner join (
			select rd2.turn_on_define_order,rd2.recon_id, rd2.dimension
			from fileservice.recon_dimensions rd2
			where rd2.recon_id = var_recon_id
			and rd2.app_type::int <> var_app_type
			and not rd2.is_deleted 
			and rd2.is_active 
		) rd2
		on rd1.turn_on_define_order=rd2.turn_on_define_order
		and rd1.recon_id = rd2.recon_id
		where rd1.recon_id = var_recon_id
		and rd1.turn_on_define_order <> '2'
		and not rd1.is_deleted
		and rd1.is_active
		and rd1.app_type::int = var_app_type
		order by rd1.turn_on_define_order::int
	) q
	group by q.recon_app_id;
	begin
		execute var_script2;
	exception
		when others
		then
			--	Log Script
			call fileService.sp_log_entry(
								null::integer,
								'''Failed run bridge tmp table creation. Error:'||sqlerrm||''''::text,
								var_recon_id::integer,
								var_name::text
								);
	end;
	/*
	 * Create the bridge view script
	 */
	select
	'select case when ''kickout'' in ('||string_agg(dim_name, ', ')||') then true else false end as kickout, * from '||s_schema_name||'.bridge_'||var_name||'_tmp' as stmt
	into var_view_script
	from
		(
		select 
			concat('"bridge-', rd1.dimension, '-', rd2.dimension, '"')::text as dim_name
		from fileservice.recon r
		inner join fileservice.recon_dimensions rd1
		on r.app1_id = rd1.recon_app_id
		and rd1.is_active 
		inner join fileservice.recon_dimensions rd2
		on rd1.turn_on_define_order = rd2.turn_on_define_order
		and r.app2_id = rd2.recon_app_id
		and rd2.is_active 
		inner join fileservice.recon_bridge_mapping rbm 
		on r.recon_id = rbm.recon_id
		and not rbm.is_deleted 
		and not rbm.is_invalid 
		and (rd1.dimensions_id = rbm.dim_id or rd2.dimensions_id = rbm.dim_id)
		where r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
		group by
			rd1.dimensions_id ,
			rd2.dimensions_id
		order by
			rd1.turn_on_define_order 
	)q1;
	/*
	 * Run loop 2 times for var_app_type 0 and 1.
	 */
	<<app_loop>>
	loop	
		if var_app_type=0
		then var_app_id=var_app1_id;
		else var_app_id=var_app2_id;
		end if;
		exit when var_app_type > 1;
	
--		raise notice '%', var_app_type;
		begin
			select 
			'with rbm_q as ( select rd.dimensions_id, rd.dimension, rbm.source_member, rbm.bridge_member, case when rbm.flip_sign then -1 else 1 end as flip_sign, rbm.dim_comment, rbm.bridge_comment, rbm.je_comment '||
			'from fileservice.recon_bridge_mapping rbm inner join fileservice.recon_dimensions rd on rbm.dim_id = rd.dimensions_id and not rd.is_deleted '||
			'where rbm.recon_id='||var_recon_id||-----------------------------------------------------------------------
			' and rbm.app_id='||var_app_id||---------------------------------------------------------------------------
			' and not rbm.is_deleted and not is_invalid) select a.app_id,'||
			string_agg(col_name,',')||
			',coalesce("AMOUNT",''0.00'')::decimal, case when app_id%2=0 then -1 else 1 end *'||string_agg(flip_sign,'*')||'*coalesce("AMOUNT",''0.00'')::decimal as sign_reversal_amount, file_name, file_id, '||
			string_agg(dim_comment,'||''^''||')||'||'||string_agg(bridge_comment,'||''^''||')||' as user_comment '||
			case when var_je then ', '||string_agg(je_comment,'||''^''||')||'' else ', '''' je_comment' end||----------------------------------------------------------------
			' from '||case when var_je then 'je_' else 'app_' end ||var_recon_id||'_'||var_app_id||' a '||
			string_agg(join_condition,' ')
			into var_script
			from (
				select 
				'a."'||rd1.dimension||'",coalesce(q_'||rd1.dimension||'.bridge_member,''kickout'') as '|| case when var_app_type=0 then '"bridge-'||rd1.dimension||'-'||rd2.dimension||'"' else '"bridge_'||rd2.dimension||'-'||rd1.dimension||'"' end as col_name
				,'coalesce(q_'||rd1.dimension||'.flip_sign,1)::int' as flip_sign
				,'coalesce(q_'||rd1.dimension||'.dim_comment,'''')' as dim_comment
				,'coalesce(q_'||rd1.dimension||'.bridge_comment,'''')' as bridge_comment
				,'coalesce(q_'||rd1.dimension||'.je_comment,'''')' as je_comment
				, 'left join rbm_q q_'||rd1.dimension||' on q_'||rd1.dimension||'.dimensions_id='||rd1.dimensions_id||' and a."'||rd1.dimension||'"=q_'||rd1.dimension||'.source_member' as join_condition
				from fileservice.recon_dimensions rd1
				inner join fileservice.recon_dimensions rd2
				on rd1.recon_id=rd2.recon_id 
				and not rd2.is_deleted 
				and rd1.turn_on_define_order=rd2.turn_on_define_order 
				and rd2.app_type::int<>var_app_type-----------------------------------------------------------
				where rd1.recon_id=var_recon_id------------------------------------------------------------
				and rd1.recon_app_id=var_app_id----------------------------------------------------------
				and rd1.turn_on_define_order <> '2'
				and rd1.app_type::int=var_app_type------------------------------------------------------------
				and not rd1.is_deleted
				order by rd1.turn_on_define_order::int
			) q;
			var_script = 'insert into '||s_schema_name||'.bridge_'||var_recon_id||'_tmp '||var_col_list||' '||var_script;
--			raise notice '%', var_script;
			execute var_script;
		exception
			when others
			then
--				raise notice '%', var_script;
				call fileservice.sp_log_entry(
					var_app_id, 
					'''Run Bridge failed during insertion to tmp table, for app '||var_app_type+1||'. Error:'||sqlerrm||'.''', 
					var_recon_id, 
					'bridge_'||var_recon_id||'_tmp'
				); 
				var_app_type = var_app_type+1;
				/*
				 * Return and continue with next file from the table
				 */
				continue app_loop;
		end;
		
		var_app_type = var_app_type+1;
	end loop;
	/*
	 * Bridge Kickouts view
	 */
	var_view_script = 'drop view if exists '||s_schema_name||'.view_bridge_'||var_name||' cascade; create view '||s_schema_name||'.view_bridge_'||var_name||' as (select * from ('||var_view_script||') q);';
	begin
		execute var_view_script;
	exception
		when others
		then
			--	Log Script
			call fileService.sp_log_entry(
								null::integer,
								'''Failed Bridge view '|| var_name || ' creation. Error:'||sqlerrm||''''::text,
								var_recon_id::integer,
								var_name::text
								);
	end;

	var_view_script = 'drop view if exists '||s_schema_name||'.view_bridge_'||var_name||'_kickout cascade; create view '||s_schema_name||'.view_bridge_'||var_name||'_kickout as (select * from '||s_schema_name||'.view_bridge_'||var_name||' where kickout);';
	begin
		execute var_view_script;
	exception
		when others
		then
			--	Log Script
			call fileService.sp_log_entry(
								null::integer,
								'''Failed Bridge kickouts view '|| var_name || ' creation. Error:'||sqlerrm||''''::text,
								var_recon_id::integer,
								var_name::text
								);
	end;

	var_name = 'view_bridge_'||var_name||'_kickout';
--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Bridge view '|| var_name || ' created'''::text,
								var_recon_id::integer,
								var_name::text
								);
	/*
	 * If no kickouts convert the bridge view into a table for further process
	 */
	execute 'select not exists (select * from fileservice.'||var_name||' limit 1);' into var_kickout;
	if var_kickout
		then
		var_script = 'drop table if exists '||s_schema_name||'.bridge_'||var_name_table||' cascade;';
		var_script = var_script || ' alter table '||s_schema_name||'.bridge_'||var_name_table||'_tmp RENAME TO bridge_'||var_name_table||';';
		execute var_script;		
--		Log Script		
		call fileService.sp_log_entry(
									null::integer,
									'''Bridge table bridge_'|| var_name_table || ' created'''::text,
									var_recon_id::integer,
									var_name_table::text
									);
		update fileservice.recon r
		set status = 'Bridged'
		where r.recon_id = var_recon_id;
	else
		call fileService.sp_log_entry(
									null::integer,
									'''Kickouts exist for view view_'|| var_name_table || '.'''::text,
									var_recon_id::integer,
									var_name_table::text
									);
		update fileservice.recon r
		set status = 'Kickouts'
		where r.recon_id = var_recon_id;
	end if;
--	raise notice 'Done';
end $procedure$
;

--Permissions
ALTER PROCEDURE fileservice.sp_create_recon_run_bridge_table(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table(int4, bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table(int4, bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table(int4, bool) TO "user_dataRecon_file";
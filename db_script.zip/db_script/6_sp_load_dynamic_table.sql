CREATE OR REPLACE PROCEDURE fileservice.sp_load_dynamic_table(recon_app_id integer, journal_entry boolean DEFAULT false)
 LANGUAGE plpgsql
AS $procedure$
DECLARE 
var_app_id integer = recon_app_id;
var_je boolean := journal_entry;
var_table_name record;
var_table boolean := false;
v_sequence bigint := 9223372036854775807;
var_count integer := 0;

var_str_to_array_delim text := '||';

var_script text := '';
var_script_2 text := '';
var_script_insert text := '';


var_dim_names text[];
v_dim text := '';
var_file record;
var_default_location text := 'C:\Workspace\PostgreSQL\Data_Recon\input\';
var_file_meta record;
s_schema_name text := 'fileservice';
v_row_count integer :=0;
v_file_count integer :=0;
v_tmp_table text := '';

v_currency_symbol text[];
v_currency_delim text[];
x text := '';
v_replace_curr_l text := '';
v_replace_curr_r text := '';

begin

	call fileservice.sp_log_entry(var_app_id, '''Preparing load''');
 
	/*
	 * This procedure assumes that the target table exists on the database with appropriate roles and privileges.
	 */

	/* 
	 * Check if the application entry exists in the recon_application table
	 */
	if
		exists(select 1 from fileservice.recon_applications ra where ra.recon_app_id=var_app_id)
		then
			select *
			into var_table_name
			from f_check_get_app_details(var_app_id, var_je) as (table_name text, rec_id integer);
		
			select string_to_array(coalesce(ra.currency_symbol,''),var_str_to_array_delim), string_to_array(coalesce(ra.currency_delimiter,'.'),var_str_to_array_delim)
			into v_currency_symbol, v_currency_delim
			from fileservice.recon_applications ra 
			where ra.recon_app_id = var_app_id
			and not ra.is_deleted;
			
		else 
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Application does not exist'''::text
									);
			return;		
	end if;

	/*
	 * Check if recon is not signed-off
	 */
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id IN (select ra.recon_id from fileservice.recon_applications ra where ra.recon_app_id=var_app_id) AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Recon is signed-off'''::text
									);
			return;		
	end if;
	
	v_tmp_table = var_table_name.table_name||'_tmp';

	/*
	 * Prepare the replace statements
	 */
	foreach x in array v_currency_symbol
	loop 
		v_replace_curr_l = 'replace('||v_replace_curr_l;
		v_replace_curr_r = v_replace_curr_r||','''||x||''','''')';
	end loop;

	foreach x in array v_currency_delim
	loop 
		v_replace_curr_l = 'replace('||v_replace_curr_l;
		v_replace_curr_r = v_replace_curr_r||','''||x||''',''.'')';
	end loop;

	/*
	 * Check if the target table exists in the database using the system table pg_catalog.pg_tables
	 */
	select exists
	into var_table
	(select from pg_catalog.pg_tables pt 
	where schemaname = s_schema_name  
	and tablename = var_table_name.table_name) q1;
--	raise notice '%', not(var_table);

	if not(var_table)
		then
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Table does not exist'''::text
									);
			return;
--			raise exception '% table does not exist',var_table_name;	
	end if;


	/*
	 * Prepare the copy statement to load the file
	 * Loop to get the dimension names that exist in the file
	 * 
	 */
--	if var_je
--	then
--		var_dim_names := array (
--				select concat('"',generate_series(1,v_max+1),'"') as col_id
--				from (
--					select count(type_field::integer) as v_max
--					from fileservice.recon_dimensions rd 
--					where rd.recon_app_id = var_app_id
--					and rd.is_active  
--					and top_member is null
--					and not rd.is_deleted
--				) q2
--		);
--	else
		var_dim_names := array (
				select concat('"',generate_series(1,v_max),'"') as col_id
				from (
					select count(type_field::integer) as v_max
					from fileservice.recon_dimensions rd 
					where rd.recon_app_id = var_app_id
					and rd.is_active  
--					and top_member is null
					and not rd.is_deleted
				) q2
		);
--	end if;

	
	/*
	 * Create intermediate temp table
	 */
	var_script = 'drop table if exists fileservice.'||v_tmp_table||' cascade; ';
	var_script = var_script || 'create table if not exists fileservice.'||v_tmp_table||'( ';

	foreach v_dim in array var_dim_names
	loop
		var_script = var_script || v_dim || '  character varying COLLATE pg_catalog."default",';
	end loop;

	if var_je
	then
		var_script = var_script||' je_comment character varying COLLATE pg_catalog."default",';
	end if;
	

	var_script = var_script || ' file_name character varying COLLATE pg_catalog."default", file_id integer) TABLESPACE tbsp_data_recon;';
--raise notice '%', var_script;
	execute var_script;
	
	/*
	 * v_dim will provide dimension names for file to temp table
	 */
	v_dim = pg_catalog.array_to_string(var_dim_names, ',') ;
	if var_je
	then
		v_dim = v_dim||',"je_comment"';
	end if;


	var_script_insert = 'insert into '||s_schema_name||'.'||var_table_name.table_name||' (';

	select
		case 
			when var_je
			then concat(string_agg(dim_name,', '),' ,je_comment ,file_name, file_id') 
			else concat(string_agg(dim_name,', '),' ,file_name, file_id')
			end
		, 
		case
			when  var_je
			then concat('select ',string_agg('replace(coalesce('||c_dim_name||','''||default_value||'''),'''''''','''')',', '),',je_comment,file_name,file_id')
			else concat('select ',string_agg('replace(coalesce('||c_dim_name||','''||default_value||'''),'''''''','''')',', '),',file_name,file_id')
			end
	into var_script, var_script_2
	from (
		select 
		'"'||rd.dimension||'"' as dim_name,
		case
			when rd.dimension='AMOUNT'
			then v_replace_curr_l||'"'||coalesce(rd.type_field,'0')||'"'||v_replace_curr_r
			--'replace(replace("'||rd.type_field||'",'''||v_currency_symbol||''',''''),'''||v_currency_delim||''',''.'')::text'
			else 
				case
					when rd.type_field is not null
					then concat('"',rd.type_field,'"')
					else 'null'
				end
		end as c_dim_name,
		case 
			when rd.dimension='AMOUNT'
			then '0'
			else coalesce(rd.top_member,'NA')
		end as default_value
		from fileservice.recon_dimensions rd 
		where rd.recon_app_id = var_app_id
		and rd.is_active  
		and not rd.is_deleted
		order by rd.type_field::integer,
		rd.dimensions_id 
	) q3;
	var_script_insert = var_script_insert||var_script||')';	
	var_script = var_script_2 || ' from '||s_schema_name||'.'||v_tmp_table;

	var_script_insert = var_script_insert||' '||var_script;
--	raise notice '%', var_script_insert;


	select import_delimiter , 
	case 
		when has_header=true
		then 'csv header'
		else ''
		end as import_header
	into var_file_meta
	from fileservice.recon_applications ra 
	where ra.recon_app_id = var_app_id
	and not ra.is_deleted;

	

	<<file_load>>
	for var_file in
		select --concat('''',coalesce(tfls.file_location, var_default_location) , tfls.file_name,'''') as file
		tfls.file_location as file_location , tfls.file_name as file, tfls.file_id as file_id
		from fileservice.track_file_load_status tfls 
		where tfls.app_id = var_app_id
		and tfls.status is null
		order by tfls .file_id
	loop 
--		raise notice '%',(not var_je and var_file.file like 'je%') or (var_je and var_file.file not like 'je%');
		/*
		 * XOR Logic to decide when to load the file 
		 */
		continue file_load when (not var_je and var_file.file like 'je%') or (var_je and var_file.file not like 'je%');
--		raise notice 'Loop Running %', var_file.file;
		
		/*
		 * log file load start time
		 */
		call fileservice.sp_log_entry(
			var_app_id, 
			'''Loading file '||var_file.file||'''', 
			var_table_name.rec_id, 
			var_table_name.table_name
		); 
	
		var_script = 'delete from '||s_schema_name||'.'||v_tmp_table;
		execute var_script;
	
		var_script = 'delete from '||s_schema_name||'.'||var_table_name.table_name||' where file_id = '||var_file.file_id;
		execute var_script;
		
		
		/*
		 * load file to tmp table
		 */
		var_script = 'copy '||s_schema_name||'.'||v_tmp_table||'('|| v_dim ||') from ';	
		var_script = var_script||''''||var_file.file_location||var_file.file||'''';
		var_script = var_script|| ' delimiter '''||var_file_meta.import_delimiter||''' '||var_file_meta.import_header||';';
--		raise notice 'var_script: %',var_script;

		begin
			execute var_script;
		exception
			when others
			then
--				raise notice '%', exception;
				update fileservice.track_file_load_status 
				set status = 'Error'
				where app_id = var_app_id
				and file_name = var_file.file;
			
				call fileservice.sp_log_entry(
					var_app_id, 
					'''Load failed for file '||var_file.file||' 0 rows Error:'||sqlerrm||'''', 
					var_table_name.rec_id, 
					var_table_name.table_name
				); 
				
				/*
				 * Return and continue with next file from the table
				 */
				continue file_load;
		end;
	
		get diagnostics v_row_count = ROW_COUNT;
		v_file_count = v_file_count+1;
	
		var_script = 'update '||s_schema_name||'.'||v_tmp_table||' set file_name = '''||var_file.file||''', file_id = '||var_file.file_id||';';
		execute var_script;
	
		/*
		 * Reset surrogate key sequence
		 * Set to max possible value so the sequence cycles back
		 */
--		raise notice 'select coalesce(max(rec_id),%) from %.%',v_sequence,s_schema_name,var_table_name.table_name;
		execute 'select coalesce(max(record_id)::bigint,'||v_sequence||') from '||s_schema_name||'.'||var_table_name.table_name into v_sequence;
--		raise notice 'Sequence: %', v_sequence;

		execute 'select setval(''recon_table_skey''::regclass,'||v_sequence||')';
		/*
		 * Move data from tmp table to dynamic table
		 */
--		raise notice 'Insert script: %', var_script_insert;
		begin
			execute var_script_insert;
		exception
			when others
			then
--				raise notice '%', var_script_insert;
				update fileservice.track_file_load_status 
				set status = 'Error'
				where app_id = var_app_id
				and file_name = var_file.file;
			
				call fileservice.sp_log_entry(
					var_app_id, 
					'''Load failed for tmp table to '||var_table_name.table_name||'  Error:'||sqlerrm||'''', 
					var_table_name.rec_id, 
					var_table_name.table_name
				); 
				
				/*
				 * Return and continue with next file from the table
				 */
				continue file_load;
		end;
	
		--log file status
		update fileservice.track_file_load_status 
		set status = 'Completed'
		where app_id = var_app_id
		and file_name = var_file.file;
--		perform pg_sleep(5);
	
		/*
		 * log file load end time
		 */
		call fileservice.sp_log_entry(
			var_app_id, 
			'''Load completed for file '||var_file.file||' '||v_row_count||' rows''', 
			var_table_name.rec_id, 
			var_table_name.table_name
		); 
		
		commit;

	end loop;

	/*
	 * Drop temporary table
	 * 
	 */

	var_script = 'drop table if exists fileservice.'||v_tmp_table||' cascade; ';
	execute var_script;

	/*
	 * Log final load status
	 */
	call fileservice.sp_log_entry(
		var_app_id, 
		'''Load completed for '||v_file_count||' files''', 
		var_table_name.rec_id, 
		var_table_name.table_name
	);
	perform 'select setval(''recon_table_skey''::regclass,9223372036854775807)';

	/*
	 * Check and update the YEAR format
	 * Execute function for app1 to update table
	 */
	select *
	into var_count
	from fileservice.f_update_table_year(var_table_name.table_name);

	/*
	 * Update log for Table1
	 */
	call fileservice.sp_log_entry(
	var_app_id, 
	'''Table '||var_table_name.table_name||', '||var_count||' records updated''', 
	var_table_name.rec_id, 
	var_table_name.table_name
	); 

END
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_load_dynamic_table(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_load_dynamic_table(int4, bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_load_dynamic_table(int4, bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_load_dynamic_table(int4, bool) TO "user_dataRecon_file";

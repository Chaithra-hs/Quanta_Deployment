CREATE OR REPLACE PROCEDURE fileservice.sp_create_report(recon_run_id integer)
 LANGUAGE plpgsql
AS $procedure$
declare
var_recon_id integer := recon_run_id;
s_schema_name text := 'fileservice';
--var_bridge_name text := 'bridge_'||var_recon_id;
var_app1_id integer;
var_app2_id integer;
var_name text;
var_round text := '';
var_query boolean := false;
var_q1_sel text := '';
var_yp text;
var_yp2 text;
var_union text;
begin
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and not(r.is_deleted))
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name--, r.variance_threshold 
			into var_app1_id, var_app2_id, var_name--, var_threshold
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and not(r.is_deleted);
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	/*
	 * Check if recon is not signed-off
	 */	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return;		
	end if;

	/*
	 * Construct
	 * 1. Crosstab Query 1
	 * 2. Crosstab Query 1 modified for Grand Total
	 * 3. Crosstab Query 2
	 * 
	 * Merge above 1,3 into Query for main pivot table
	 * union 2
	 * add 'order_by column is to force the 'Grand Total' record to the end'
	 * 
	 * convert all of above to with clause and add:
	 * 'Below query will use with clause as the source table'
	 * 
	 * Store above as view or table
	 *   
	 */


	/* Procedure call to sp_recon_report*/
	call fileservice.sp_recon_report(var_recon_id); 
							
--	var_union = 'select * from '||s_schema_name||'.report_'||var_recon_id||' where '||var_union||' <> ''Grand Total'' union';

	 
	
	execute 'select exists (select 1 from information_schema."tables" where table_schema = '''||s_schema_name||''' and table_name = ''bridge_je_'||var_recon_id||''')'
	into var_query;
--	execute 'select 1 from information_schema."views" v where v.table_schema = '''||s_schema_name||''' and v.table_name = ''view_bridge_je_'||var_recon_id||'_kickout'''
--	into var_q1_sel;
--	raise notice '%', var_query;
	

	/*
	 * Same process as above, but for Journal Entries
	 */
	if var_query
		then
	/* Procedure call to sp_recon_je_report */
		call fileservice.sp_recon_je_report(var_recon_id);
	end if;

	/*
	 * Join report and je_report(if exists) to create another table
	 * This will create the final report for variance calculation irrespective of report_je table 
	 */
	call fileservice.sp_final_report(var_recon_id, var_query);

	update fileservice.recon 
	set status = 'Reporting'
	where recon_id = var_recon_id;	

end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_create_report(int4) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_create_report(int4) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_create_report(int4) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_create_report(int4) TO "user_dataRecon_file";

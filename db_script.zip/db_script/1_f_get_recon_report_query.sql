CREATE OR REPLACE FUNCTION fileservice.f_get_recon_report_query(recon_id integer, journal_entry boolean DEFAULT false)
 RETURNS SETOF record
 LANGUAGE plpgsql
AS $function$
declare
var_recon_id integer := recon_id;
var_je boolean := journal_entry;
var_bridge text;
var_table_rec RECORD;
begin
	if var_je
	then var_bridge = 'bridge-';
	else var_bridge = 'bridgesync-';
	end if;

	if
		exists (select 1 from fileservice.recon_dimensions rd where rd.recon_id = var_recon_id and in_recon and is_active and rd.turn_on_define_order not in ('0','1','2'))
	then
	/*
	 * Display selected dimensions
	 */
		return query 
		select
		concat(
			'concat(',
			string_agg(case when turn_on_define_order not in (0,1,2) then 'upper('||dim_name||')' else null end,',''''|'''','),',''''|'''',',
--			'concat(',string_agg(case when turn_on_define_order not in (0,1,2) then bridge_comment else null end,',''''^'''','),
--			')',
			'user_comment,''''|'''',',
			case when var_je then '"je_comment"' else '''''''''' end,
			') as conc',',',
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
		) as sel_clause_1, ----------------------------------------------------------------------------------------------------------------------
		case
			when not var_je
			then 'sum("AMOUNT-AMOUNT")'
			else 'sum("AMOUNT-AMOUNT")'/*'sum(sign_reversal_AMOUNT)'*/
		end as amt,------------------------------------------------------------------------------------------------------------------------------
		/*concat(
			'concat(''''Grand Total''''',
			string_agg('',''),
			') as conc',',',
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
		) as sel_clause_gt,*/ ---------------------------------------------------------------------------------------------------------------------
		concat(
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period'
		) as sel_clause_category,----------------------------------------------------------------------------------------------------------------
		/*array_append(*/array_agg(case when turn_on_define_order not in (0,1,2) then dim_name end)||array ['"bridge-comment"','"je-comment"']
		/*)*/ as dim_name, ----------------------------------------------------------------------------------------------------------------------
		trim(string_agg(dim_year,'')) as dim_year, ----------------------------------------------------------------------------------------------
		trim(string_agg(dim_period,'')) as dim_period -------------------------------------------------------------------------------------------
		from (
			select
			dim_name,
			dim_year, dim_period,
			case
				when not var_je
				then concat('case ',string_agg(bridge_comment,' ') /*over (partition by turn_on_define_order::integer)*/,' else '''''''' end')
				else '''''|^|'''''
			end as bridge_comment,
			order_by, turn_on_define_order::integer
			from (
				with cte_recon_dimension as (
					select
					rdi.dimension
					,rdi.dimensions_id
					,rdi.turn_on_define_order
					, rdi.recon_app_id
					from fileservice.recon_dimensions rdi
					where rdi.recon_id = var_recon_id --------------------------------------------------------------------------------------------------------------------------
					and not rdi.is_deleted 
					and rdi.is_active
					and (rdi.turn_on_define_order in ('0','1','2') or rdi.in_recon)
				)
				select concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') as dim_name,
				case when rd1.turn_on_define_order::integer = 0 then concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_year,
				case when rd1.turn_on_define_order::integer = 1 then concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_period,
				concat('when trim(lower("',var_bridge,rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''''',rbm.source_member,''''')) then ',case when rbm.bridge_comment is null then 'null' else ''''''||rbm.bridge_comment||'''''' end,'') as bridge_comment,
--				concat('when trim(lower("',var_bridge,rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''''',rbm.source_member,''''')) then ',case when rbm.je_comment is null then 'null' else ''''''||rbm.je_comment||'''''' end,'') as je_comment,
				rd1.turn_on_define_order, 1 as order_by 
				from fileservice.recon r 
				inner join cte_recon_dimension rd1
				on rd1.recon_app_id = r.app1_id 
				inner join cte_recon_dimension rd2
				on rd2.recon_app_id = r.app2_id 
				and rd1.turn_on_define_order = rd2.turn_on_define_order 
				inner join fileservice.recon_bridge_mapping rbm 
				on r.recon_id = rbm.recon_id 
				and (rd1.dimensions_id=rbm.dim_id or rd2.dimensions_id=rbm.dim_id)
				and not rbm.is_deleted 
				and not rbm.is_invalid 
				where r.recon_id = var_recon_id --------------------------------------------------------------------------------------------------------------------------
				and rd1.dimension <> 'AMOUNT'
			) q
			group by dim_name, dim_year, dim_period, turn_on_define_order::int, order_by
			order by order_by, turn_on_define_order
		) q2;
	else
	/*
	 * Default display all dimensions
	 */
		return query 
		select
		concat(
			'concat(',
			string_agg(case when turn_on_define_order not in (0,1,2) then 'upper('||dim_name||')' else null end,',''''|'''','),',''''|'''',',
--			'concat(',string_agg(case when turn_on_define_order not in (0,1,2) then bridge_comment else null end,',''''^'''','),
--			')',
			'user_comment,''''|'''',',
			case when var_je then '"je_comment"' else '''''''''' end,
			') as conc',',',
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
		) as sel_clause_1, ----------------------------------------------------------------------------------------------------------------------
		case
			when not var_je
			then 'sum("AMOUNT-AMOUNT")'
			else 'sum("AMOUNT-AMOUNT")'/*'sum(sign_reversal_AMOUNT)'*/
		end as amt,------------------------------------------------------------------------------------------------------------------------------
		/*concat(
			'concat(''''Grand Total''''',
			string_agg('',''),
			') as conc',',',
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period',','
		) as sel_clause_gt,*/ ---------------------------------------------------------------------------------------------------------------------
		concat(
		'concat(',string_agg(case when turn_on_define_order in (0,1) then dim_name else null end,','),') as year_period'
		) as sel_clause_category,----------------------------------------------------------------------------------------------------------------
		/*array_append(*/array_agg(case when turn_on_define_order not in (0,1,2) then dim_name end)||array ['"bridge-comment"','"je-comment"']
		/*)*/ as dim_name, ----------------------------------------------------------------------------------------------------------------------
		trim(string_agg(dim_year,'')) as dim_year, ----------------------------------------------------------------------------------------------
		trim(string_agg(dim_period,'')) as dim_period -------------------------------------------------------------------------------------------
		from (select
			dim_name,
			dim_year, dim_period,
			case
				when not var_je
				then concat('case ',string_agg(bridge_comment,' ') /*over (partition by turn_on_define_order::integer)*/,' else '''''''' end')
				else 'null'
			end as bridge_comment,
			order_by, turn_on_define_order::integer
			from (
				with cte_recon_dimension as (
					select
					rdi.dimension
					,rdi.dimensions_id
					,rdi.turn_on_define_order
					, rdi.recon_app_id
					from fileservice.recon_dimensions rdi
					where rdi.recon_id = var_recon_id --------------------------------------------------------------------------------------------------------------------------
					and not rdi.is_deleted 
					and rdi.is_active
				)
				select concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') as dim_name,
				case when rd1.turn_on_define_order::integer = 0 then concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_year,
				case when rd1.turn_on_define_order::integer = 1 then concat('"',var_bridge,rd1.dimension,'-',rd2.dimension,'"') else '' end as dim_period,
				concat('when trim(lower("',var_bridge,rd1.dimension,'-',rd2.dimension,'"))=trim(lower(''''',rbm.source_member,''''')) then ',case when rbm.bridge_comment is null then 'null' else ''''''||rbm.bridge_comment||'''''' end,'') as bridge_comment,
				rd1.turn_on_define_order, 1 as order_by 
				from fileservice.recon r 
				inner join cte_recon_dimension rd1
				on rd1.recon_app_id = r.app1_id 
				inner join cte_recon_dimension rd2
				on rd2.recon_app_id = r.app2_id 
				and rd1.turn_on_define_order = rd2.turn_on_define_order
				inner join fileservice.recon_bridge_mapping rbm 
				on r.recon_id = rbm.recon_id 
				and (rd1.dimensions_id=rbm.dim_id or rd2.dimensions_id=rbm.dim_id)
				and not rbm.is_deleted 
				and not rbm.is_invalid 
				where r.recon_id = var_recon_id --------------------------------------------------------------------------------------------------------------------------
				and rd1.dimension <> 'AMOUNT'
			) q
			group by dim_name, dim_year, dim_period, turn_on_define_order::int, order_by
			order by order_by, turn_on_define_order
		) q2;		
	end if;
--return;
end;
$function$
;

-- Permissions

ALTER FUNCTION fileservice.f_get_recon_report_query(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON FUNCTION fileservice.f_get_recon_report_query(int4, bool) TO public;
GRANT ALL ON FUNCTION fileservice.f_get_recon_report_query(int4, bool) TO postgres;
GRANT ALL ON FUNCTION fileservice.f_get_recon_report_query(int4, bool) TO "user_dataRecon_file";
